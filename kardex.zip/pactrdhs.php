<?php

include 'dat/cdb/db.php';


$nh = $_REQUEST['nh'];
$gra = $_REQUEST['gra'];
$hor = $_REQUEST['hor'];// Iddh




$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idmat = $_REQUEST['Idmat'];
$Idgra = $_REQUEST['Idgra'];
$Idsal = $_REQUEST['Idsal'];
$Iddoc = $_REQUEST['Iddoc'];
$Idh   = $_REQUEST['Idh'];

 

$resultado=mysqli_query($db_connection, "SELECT Dia, Horario FROM docentesh WHERE Iddh= '".$hor."' ");



if (mysqli_num_rows($resultado)>0)

{



while ($row =mysqli_fetch_array($resultado)) {

   	 $dia=$row[Dia];

    $horario=$row[Horario];

}





$resulta=mysqli_query($db_connection, "SELECT Iddh FROM detalleh WHERE Idh= '".$Idh."' ");





while ($rowx =mysqli_fetch_array($resulta))

   	 $Iddhx=$rowx[Iddh];

    



$update_value = "UPDATE docentesh SET  Estado=1 WHERE Iddh='".$Iddhx."'";



$retry_value = mysqli_query($db_connection,$update_value);





$update_value = "UPDATE docentesh SET  Estado=2 WHERE Iddh='".$hor."'";



$retry_value1 = mysqli_query($db_connection,$update_value);



$update_value = "UPDATE detalleh SET  Dia='".$dia."', Horario='".$horario."', Iddh='".$hor."' WHERE Idh='".$Idh."'";

 

$retry_value2 = mysqli_query($db_connection,$update_value);



mysqli_free_result($resulta);

mysqli_free_result($retry_value1);

mysqli_free_result($retry_value1);

mysqli_free_result($retry_value2);




$men="Horario actualizado";



header('Location: regrdhs.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');


 } else {





$men="Seleccionar el horario del docente";




header('Location: regrdhs.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');






}



mysqli_free_result($resultado);

mysqli_close($db_connection);

?>





