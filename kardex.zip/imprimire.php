<?php

include 'fpdf.php';
include 'dat/cdb/db.php';

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Iddoc = $_REQUEST['Iddoc'];


class PDF extends FPDF
{
protected $B = 0;
protected $I = 0;
protected $U = 0;
protected $HREF = '';

function WriteHTML($html)
{
    // Intérprete de HTML
    $html = str_replace("\n",' ',$html);
    $a = preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
    foreach($a as $i=>$e)
    {
        if($i%2==0)
        {
            // Text
            if($this->HREF)
                $this->PutLink($this->HREF,$e);
            else
                $this->Write(5,$e);
        }
        else
        {
            // Etiqueta
            if($e[0]=='/')
                $this->CloseTag(strtoupper(substr($e,1)));
            else
            {
                // Extraer atributos
                $a2 = explode(' ',$e);
                $tag = strtoupper(array_shift($a2));
                $attr = array();
                foreach($a2 as $v)
                {
                    if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
                        $attr[strtoupper($a3[1])] = $a3[2];
                }
                $this->OpenTag($tag,$attr);
            }
        }
    }
}

function OpenTag($tag, $attr)
{
    // Etiqueta de apertura
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,true);
    if($tag=='A')
        $this->HREF = $attr['HREF'];
    if($tag=='BR')
        $this->Ln(5);
}

function CloseTag($tag)
{
    // Etiqueta de cierre
    if($tag=='B' || $tag=='I' || $tag=='U')
        $this->SetStyle($tag,false);
    if($tag=='A')
        $this->HREF = '';
}

function SetStyle($tag, $enable)
{
    // Modificar estilo y escoger la fuente correspondiente
    $this->$tag += ($enable ? 1 : -1);
    $style = '';
    foreach(array('B', 'I', 'U') as $s)
    {
        if($this->$s>0)
            $style .= $s;
    }
    $this->SetFont('',$style);
}

function PutLink($URL, $txt)
{
    // Escribir un hiper-enlace
    $this->SetTextColor(0,0,255);
    $this->SetStyle('U',true);
    $this->Write(5,$txt,$URL);
    $this->SetStyle('U',false);
    $this->SetTextColor(0);
}
}




//------numero a letras----------//

function unidad($numuero){ 
    switch ($numuero) 
    { 
    case 9: 
    { 
    $numu = "NUEVE"; 
    break; 
    } 
    case 8: 
    { 
    $numu = "OCHO"; 
    break; 
    } 
    case 7: 
    { 
    $numu = "SIETE"; 
    break; 
    } 
    case 6: 
    { 
    $numu = "SEIS"; 
    break; 
    } 
    case 5: 
    { 
    $numu = "CINCO"; 
    break; 
    } 
    case 4: 
    { 
    $numu = "CUATRO"; 
    break; 
    } 
    case 3: 
    { 
    $numu = "TRES"; 
    break; 
    } 
    case 2: 
    { 
    $numu = "DOS"; 
    break; 
    } 
    case 1: 
    { 
    $numu = "UNO"; 
    break; 
    } 
    case 0: 
    { 
    $numu = ""; 
    break; 
    } 
    } 
    return $numu; 
    } 
    
    function decena($numdero){ 
    
    if ($numdero >= 90 && $numdero <= 99) 
    { 
    $numd = "NOVENTA "; 
    if ($numdero > 90) 
    $numd = $numd."Y ".(unidad($numdero - 90)); 
    } 
    else if ($numdero >= 80 && $numdero <= 89) 
    { 
    $numd = "OCHENTA "; 
    if ($numdero > 80) 
    $numd = $numd."Y ".(unidad($numdero - 80)); 
    } 
    else if ($numdero >= 70 && $numdero <= 79) 
    { 
    $numd = "SETENTA "; 
    if ($numdero > 70) 
    $numd = $numd."Y ".(unidad($numdero - 70)); 
    } 
    else if ($numdero >= 60 && $numdero <= 69) 
    { 
    $numd = "SESENTA "; 
    if ($numdero > 60) 
    $numd = $numd."Y ".(unidad($numdero - 60)); 
    } 
    else if ($numdero >= 50 && $numdero <= 59) 
    { 
    $numd = "CINCUENTA "; 
    if ($numdero > 50) 
    $numd = $numd."Y ".(unidad($numdero - 50)); 
    } 
    else if ($numdero >= 40 && $numdero <= 49) 
    { 
    $numd = "CUARENTA "; 
    if ($numdero > 40) 
    $numd = $numd."Y ".(unidad($numdero - 40)); 
    } 
    else if ($numdero >= 30 && $numdero <= 39) 
    { 
    $numd = "TREINTA "; 
    if ($numdero > 30) 
    $numd = $numd."Y ".(unidad($numdero - 30)); 
    } 
    else if ($numdero >= 20 && $numdero <= 29) 
    { 
    if ($numdero == 20) 
    $numd = "VEINTE "; 
    else 
    $numd = "VEINTI".(unidad($numdero - 20)); 
    } 
    else if ($numdero >= 10 && $numdero <= 19) 
    { 
    switch ($numdero){ 
    case 10: 
    { 
    $numd = "DIEZ "; 
    break; 
    } 
    case 11: 
    { 
    $numd = "ONCE "; 
    break; 
    } 
    case 12: 
    { 
    $numd = "DOCE "; 
    break; 
    } 
    case 13: 
    { 
    $numd = "TRECE "; 
    break; 
    } 
    case 14: 
    { 
    $numd = "CATORCE "; 
    break; 
    } 
    case 15: 
    { 
    $numd = "QUINCE "; 
    break; 
    } 
    case 16: 
    { 
    $numd = "DIECISEIS "; 
    break; 
    } 
    case 17: 
    { 
    $numd = "DIECISIETE "; 
    break; 
    } 
    case 18: 
    { 
    $numd = "DIECIOCHO "; 
    break; 
    } 
    case 19: 
    { 
    $numd = "DIECINUEVE "; 
    break; 
    } 
    } 
    } 
    else 
    $numd = unidad($numdero); 
    return $numd; 
    } 
    
    function centena($numc){ 
    if ($numc >= 100) 
    { 
    if ($numc >= 900 && $numc <= 999) 
    { 
    $numce = "NOVECIENTOS "; 
    if ($numc > 900) 
    $numce = $numce.(decena($numc - 900)); 
    } 
    else if ($numc >= 800 && $numc <= 899) 
    { 
    $numce = "OCHOCIENTOS "; 
    if ($numc > 800) 
    $numce = $numce.(decena($numc - 800)); 
    } 
    else if ($numc >= 700 && $numc <= 799) 
    { 
    $numce = "SETECIENTOS "; 
    if ($numc > 700) 
    $numce = $numce.(decena($numc - 700)); 
    } 
    else if ($numc >= 600 && $numc <= 699) 
    { 
    $numce = "SEISCIENTOS "; 
    if ($numc > 600) 
    $numce = $numce.(decena($numc - 600)); 
    } 
    else if ($numc >= 500 && $numc <= 599) 
    { 
    $numce = "QUINIENTOS "; 
    if ($numc > 500) 
    $numce = $numce.(decena($numc - 500)); 
    } 
    else if ($numc >= 400 && $numc <= 499) 
    { 
    $numce = "CUATROCIENTOS "; 
    if ($numc > 400) 
    $numce = $numce.(decena($numc - 400)); 
    } 
    else if ($numc >= 300 && $numc <= 399) 
    { 
    $numce = "TRESCIENTOS "; 
    if ($numc > 300) 
    $numce = $numce.(decena($numc - 300)); 
    } 
    else if ($numc >= 200 && $numc <= 299) 
    { 
    $numce = "DOSCIENTOS "; 
    if ($numc > 200) 
    $numce = $numce.(decena($numc - 200)); 
    } 
    else if ($numc >= 100 && $numc <= 199) 
    { 
    if ($numc == 100) 
    $numce = "CIEN "; 
    else 
    $numce = "CIENTO ".(decena($numc - 100)); 
    } 
    } 
    else 
    $numce = decena($numc); 
    
    return $numce; 
    } 
    
    function miles($nummero){ 
    if ($nummero >= 1000 && $nummero < 2000){ 
    $numm = "MIL ".(centena($nummero%1000)); 
    } 
    if ($nummero >= 2000 && $nummero <10000){ 
    $numm = unidad(Floor($nummero/1000))." MIL ".(centena($nummero%1000)); 
    } 
    if ($nummero < 1000) 
    $numm = centena($nummero); 
    
    return $numm; 
    } 
    
    function decmiles($numdmero){ 
    if ($numdmero == 10000) 
    $numde = "DIEZ MIL"; 
    if ($numdmero > 10000 && $numdmero <20000){ 
    $numde = decena(Floor($numdmero/1000))."MIL ".(centena($numdmero%1000)); 
    } 
    if ($numdmero >= 20000 && $numdmero <100000){ 
    $numde = decena(Floor($numdmero/1000))." MIL ".(miles($numdmero%1000)); 
    } 
    if ($numdmero < 10000) 
    $numde = miles($numdmero); 
    
    return $numde; 
    } 
    
    function cienmiles($numcmero){ 
    if ($numcmero == 100000) 
    $num_letracm = "CIEN MIL"; 
    if ($numcmero >= 100000 && $numcmero <1000000){ 
    $num_letracm = centena(Floor($numcmero/1000))." MIL ".(centena($numcmero%1000)); 
    } 
    if ($numcmero < 100000) 
    $num_letracm = decmiles($numcmero); 
    return $num_letracm; 
    } 
    
    function millon($nummiero){ 
    if ($nummiero >= 1000000 && $nummiero <2000000){ 
    $num_letramm = "UN MILLON ".(cienmiles($nummiero%1000000)); 
    } 
    if ($nummiero >= 2000000 && $nummiero <10000000){ 
    $num_letramm = unidad(Floor($nummiero/1000000))." MILLONES ".(cienmiles($nummiero%1000000)); 
    } 
    if ($nummiero < 1000000) 
    $num_letramm = cienmiles($nummiero); 
    
    return $num_letramm; 
    } 
    
    function decmillon($numerodm){ 
    if ($numerodm == 10000000) 
    $num_letradmm = "DIEZ MILLONES"; 
    if ($numerodm > 10000000 && $numerodm <20000000){ 
    $num_letradmm = decena(Floor($numerodm/1000000))."MILLONES ".(cienmiles($numerodm%1000000)); 
    } 
    if ($numerodm >= 20000000 && $numerodm <100000000){ 
    $num_letradmm = decena(Floor($numerodm/1000000))." MILLONES ".(millon($numerodm%1000000)); 
    } 
    if ($numerodm < 10000000) 
    $num_letradmm = millon($numerodm); 
    
    return $num_letradmm; 
    } 
    
    function cienmillon($numcmeros){ 
    if ($numcmeros == 100000000) 
    $num_letracms = "CIEN MILLONES"; 
    if ($numcmeros >= 100000000 && $numcmeros <1000000000){ 
    $num_letracms = centena(Floor($numcmeros/1000000))." MILLONES ".(millon($numcmeros%1000000)); 
    } 
    if ($numcmeros < 100000000) 
    $num_letracms = decmillon($numcmeros); 
    return $num_letracms; 
    } 
    
    function milmillon($nummierod){ 
    if ($nummierod >= 1000000000 && $nummierod <2000000000){ 
    $num_letrammd = "MIL ".(cienmillon($nummierod%1000000000)); 
    } 
    if ($nummierod >= 2000000000 && $nummierod <10000000000){ 
    $num_letrammd = unidad(Floor($nummierod/1000000000))." MIL ".(cienmillon($nummierod%1000000000)); 
    } 
    if ($nummierod < 1000000000) 
    $num_letrammd = cienmillon($nummierod); 
    
    return $num_letrammd; 
    } 
    
    function convertir($numero){ 
    $tempnum = explode('.',$numero); 
    
    if ($tempnum[0] !== ""){ 
    $numf = milmillon($tempnum[0]); 
    if ($numf == "UNO") 
    { 
    $numf = substr($numf, 0, -1); 
    $Ps = " PESO "; 
    } 
    else 
    { 
    $Ps = " PESOS "; 
    } 
    $TextEnd = $numf; 
    $TextEnd .= $Ps; 
    } 
    if ($tempnum[1] == "" || $tempnum[1] >= 100) 
    { 
    $tempnum[1] = "00" ; 
    } 
    $TextEnd .= $tempnum[1] ; 
    $TextEnd .= "/100 M.N."; 
    return $TextEnd; 
    }
    
//-------numero a letras--------//

date_default_timezone_set('America/Mexico_City');
$originalDate = date(DATE_RFC2822);
$originalDate = date("d-m-Y", strtotime($originalDate));
$originalTime = date("H:i:s");

$sqle = "SELECT Logo FROM escuelas WHERE Idesc= '".$Idesc."' ";
$resulte = mysqli_query($db_connection, $sqle);

while ($rowe =mysqli_fetch_array($resulte))
 $log= $rowe[Logo]; 



mysqli_free_result($resulte);

$pdf=new FPDF();

$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Image('dat/logotipos/'.$log,5,5,-250,0,'','pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'');

$sql = "SELECT Nombres, Idesc FROM usuarios WHERE Idusu= '".$Idusu."' ";
$result = mysqli_query($db_connection, $sql);

while ($row =mysqli_fetch_array($result))
 $Usuario= $row[Nombres]; 

$sql2 = "SELECT Escuela FROM escuelas WHERE Idesc = '".$Idesc."' ORDER BY Idesc ASC";
$result2 = mysqli_query($db_connection, $sql2);

while ($row2 =mysqli_fetch_array($result2))
 $esc=$row2[Escuela];

$esc=utf8_decode($esc);


$pdf->Cell(0,8,'                                '.$esc.' | ',0,1);
$pdf->Cell(0,8,'                                Fecha:  '.$originalDate,0,1);

mysqli_free_result($result);
mysqli_free_result($result2);


$sqla = "SELECT Nombres, Apellidos,  Movil, Correo, Idesc FROM docentes WHERE Iddoc = '".$Iddoc."' ";

$resulta = mysqli_query($db_connection, $sqla );
while ($rowa =mysqli_fetch_array($resulta)){ 
     $nom=$rowa[Nombres];
     $ape=$rowa[Apellidos];
     $mov=$rowa[Movil];
     $cor=$rowa[Correo];
     $Idesc=$rowa[Idesc];
}

mysqli_free_result($resulta);

 $pdf->Ln();
 $pdf->SetFont('Arial','',14);

$nom=utf8_decode($nom);
$ape=utf8_decode($ape);


 $pdf->Cell(0,8,'                '.$nom.'  | '.$ape.'  | '.$mov.' | '.$cor,0,1);



$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,8,'                                    PAGO',0,1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 4, '   ASIGNADAS  CANTIDAD       MATERIA                                                         COSTO   DESCUENTO       IMPORTE ', 0, 1);

$pdf->SetFont('Arial', '', 10);


$sqlco = "SELECT Fecha, Hora, Folio, Asignada, Cantidad, Materia, Costo, Importe, Descuento, Subtotal, Total,  Letras FROM pagos WHERE  Iddoc = '".$Iddoc."' && Estado=0 ";

$descu=0;
$imp=0;
$sub=0;
$tot=0;

$celda=4;

$resultco = mysqli_query($db_connection,$sqlco);
while ($rowco=mysqli_fetch_array($resultco)){ 

$fol=$rowco[Folio];

$descrip=utf8_decode($rowco[Descripcion]);

$pdf->Cell(0,$celda,'           '.$rowco[Asignada].'                     '.$rowco[Cantidad].'                 '.$rowco[Materia].'                                                         '.$rowco[Costo].'            $'.$rowco[Descuento].'                     $'.$rowco[Importe].'     ',0,1);                                                                                                                                                                                                                                                     
$imp+=$rowco[Importe];
$descu+=$rowco[Descuento];

$celda=$celda+2;

}


$sub=$imp-$descu;
$tot=$sub;

$pdf->Cell(0,$celda,'SUBTOTAL      $'.$sub,0,1);
$pdf->Cell(0,$celda,'DESCUENTO.    $'.$descu,0,1);
$pdf->Cell(0,$celda,'TOTAL              $'.$tot,0,1);

$let=convertir($tot);

$pdf->Cell(0,$celda,'CANTIDAD EN LETRAS :'.$let,0,1);

mysqli_free_result($resultco);

$celda=$celda+3;

$pdf->Cell(0,$celda,' Folio: '.$fol,0,1);
$pdf->Cell(0,$celda,'Usuario: '.$Usuario,0,1);


$update_value ="UPDATE pagos SET Estado=1 WHERE Folio='".$fol."' ";

$retry_value = mysqli_query($db_connection,$update_value);



$pdf->Output();	
mysqli_close($db_connection);
?>
