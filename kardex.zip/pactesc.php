<?php



include 'dat/cdb/db.php';



$esc = $_REQUEST['esc'];

$ubi = $_REQUEST['ubi'];

$tel = $_REQUEST['tel'];

$cor = $_REQUEST['cor'];

$fir = $_REQUEST['fir'];

$iva = $_REQUEST['iva'];

$rec = $_REQUEST['rec'];

$rev = $_REQUEST['rev'];


$Idesc = $_REQUEST['Idesc'];

$Idusu = $_REQUEST['Idusu'];



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());





$update_value ="UPDATE escuelas SET Escuela='".$esc."',Ubicacion='".$ubi."', Correo='".$cor."', Telefono='".$tel."', Rector='".$rec."', Revoe='".$rev."', Firma='".$fir."', Iva='".$iva."'  WHERE Idesc='".$Idesc."' ";



$retry_value = mysqli_query($db_connection,$update_value);



$men="Instituto actualizado";



header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&men='.$men.'');







mysqli_free_result($retry_value);



mysqli_close($db_connection);

?>


