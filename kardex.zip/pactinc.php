<?php
include 'dat/cdb/db.php';

$mod = $_REQUEST['mod'];
$can = $_REQUEST['can'];
$tip = $_REQUEST['tip'];
$des = $_REQUEST['des'];
$fec = $_REQUEST['fec'];
$hor = $_REQUEST['hor'];

$Idemp = $_REQUEST['Idemp'];
$Idusu = $_REQUEST['Idusu'];
$Idinc = $_REQUEST['Idinc'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$update_value ="UPDATE incubadoras SET Modelo='".$mod."', Cantidad='".$can."', Tipo='".$tip."', Descrip='".$des."', Fecha='".$fec."', Hora='".$hor."' WHERE Idinc='".$Idinc."' ";

$retry_value = mysqli_query($db_connection,$update_value);


header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'&Idinc='.$Idinc.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
