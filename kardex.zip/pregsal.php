<?php



include 'dat/cdb/db.php';



$tur = $_REQUEST['select1'];

$gra = $_REQUEST['select2'];
$gram = $_REQUEST['select2'];

$gru = $_REQUEST['select3'];

$cos = $_REQUEST['cos'];



if($tur==1)

$tur=

"Matutino";

if($tur==2)

$tur=

"Vespertino";

if($tur==3)

$tur=

"Mixto";





if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";





if($gru==1)

$gru=

"A";

if($gru==2)

$gru=

"B";

if($gru==3)

$gru=

"C";

if($gru==4)

$gru=

"D";

if($gru==5)

$gru=

"E";

if($gru==6)

$gru=

"F";

if($gru==7)

$gru=

"G";

if($gru==8)

$gru=

"H";

if($gru==9)

$gru=

"I";

if($gru==10)

$gru=

"J";

  



$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];

$Idcar = $_REQUEST['Idcar'];

$Idcic = $_REQUEST['Idcic'];



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());







if($Idcic>0)

{



$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");

if (mysqli_num_rows($resultado)>0)
{


$result=mysqli_query($db_connection, "SELECT Idgra FROM grados WHERE Grado='".$gra."' && Idcar='".$Idcar."' ");

 

if (mysqli_num_rows($result)<=0)
{

$insert_value = "INSERT INTO grados (Grado, Costo, Idgram, Idcar) VALUES ('".$gra."', '".$cos."', '".$gram."', '".$Idcar."')";


$retry_value2 = mysqli_query($db_connection,$insert_value);

$result=mysqli_query($db_connection, "SELECT Idgra FROM grados WHERE Grado='".$gra."' && Idcar='".$Idcar."' ");

while ($row =mysqli_fetch_array($result)) 
   	 $Idgra=$row[Idgra];


}


if (mysqli_num_rows($result)>0)
{
while ($row =mysqli_fetch_array($result)) 
   	 $Idgra=$row[Idgra];

$update_value = "UPDATE grados SET  Costo='".$cos."'  WHERE Idgra='".$Idgra."'";

$retry_value3 = mysqli_query($db_connection,$update_value);
}



$insert_value = "INSERT INTO salones (Turno, Grado, Grupo, Idgra, Idcic) VALUES ('".$tur."', '".$gra."', '".$gru."', '".$Idgra."', '".$Idcic."')";



$retry_value = mysqli_query($db_connection,$insert_value);





$result1=mysqli_query($db_connection, "SELECT Idsal FROM  salones WHERE Turno = '".$tur."' && Grado = '".$gra."' && Grupo = '".$gru."' && Idcic = '".$Idcic."'");





while ($row1 =mysqli_fetch_array($result1)) {
   	 $Idsal=$row1[Idsal];
   }



$men="Agregó el Salón";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');


 } else {



header('Location: index.php?cic='.$cic.'');



}

mysqli_free_result($retry_value);



mysqli_free_result($retry_value2);

mysqli_free_result($retry_value3);

mysqli_free_result($resultado);

mysqli_free_result($result1);

mysqli_free_result($result);

mysqli_close($db_connection);

}else {



$men="Seleccionar el ciclo";



header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');



}

?>










