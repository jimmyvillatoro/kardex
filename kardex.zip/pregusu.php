﻿<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];


date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());



$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Correo = '".$cor."' ");
 

if (mysqli_num_rows($resultado)>0)
header('Location: index.php?nom='.$nom.'& mov='.$mov.'&cor='.$cor.''); else {


$insert_value = "INSERT INTO usuarios (Nombres, Apellidos, Correo, Movil, Pass, Estado) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."', 1)";

$retry_value = mysqli_query($db_connection,$insert_value);

mysqli_free_result($retry_value);

$cuerpo='Nombre: '. $nom.'  Movil: '.$mov.'  Correo: '.$cor;

mail('soporte@yaprendo.com','Un Usuario dale seguimiento->',$cuerpo,'Equipo Kardex');

$result=mysqli_query($db_connection, "SELECT Idusu FROM usuarios  WHERE Correo = '".$cor."' ");


while ($rowx =mysqli_fetch_array($result))
   	 $Idusu=$rowx[Idusu];
   

$men="Agregó el Usuario";

header('Location: usuarios.php?Idusu='.$Idusu.'&men='.$men.'');

}

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
