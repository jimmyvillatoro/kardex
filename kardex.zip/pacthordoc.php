<?php
include 'dat/cdb/db.php';

$dia = $_REQUEST['dia'];//día docente
$Ideh = $_REQUEST['hor'];// id escuelash
$est = $_REQUEST['est'];//estado docente


$Iddoc = $_REQUEST['Iddoc'];
$Idesc = $_REQUEST['Idesc'];
$Idcic = $_REQUEST['Idcic'];
$Iddh  = $_REQUEST['Iddh'];
$H = $_REQUEST['H']; //horario del docente

//horario de la escuela

$result=mysqli_query($db_connection, "SELECT Horario FROM escuelash WHERE Ideh='".$Ideh."' ");

  
while ($rowx =mysqli_fetch_array($result))
     $hor=$rowx[Horario];


//horario docente no esté 
$resultado=mysqli_query($db_connection, "SELECT count(Iddh) n FROM docentesh WHERE Dia='".$dia."' && Horario ='".$H."' && Iddoc='".$Iddoc."' ");
 
while($rowy=mysqli_fetch_array($resultado))
    $n=$rowy[n];

if($n<=0)
{

$update_value = "UPDATE docentesh SET Dia='".$dia."', Horario='".$hor."', Estado='".$est."', Ideh='".$Ideh."' WHERE Iddh='".$Iddh."' ";

$retry_value = mysqli_query($db_connection,$update_value);

mysqli_free_result($retry_value);
}


$men="Horario actualizado";


header('Location: reghordoc.php?Iddoc='.$Iddoc.'&Idesc='.$Idesc.'&Idcic='.$Idcic.'&Iddh='.$Iddh.'&men='.$men.'');


mysqli_free_result($resultado);
mysqli_free_result($result);
mysqli_close($db_connection);
?>
