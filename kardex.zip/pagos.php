<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Pagos Kardex</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Idusu= utf8_decode($_GET['Idusu']);
$Idesc= utf8_decode($_GET['Idesc']);$Idcar= utf8_decode($_GET['Idcar']);
$Idcic= utf8_decode($_GET['Idcic']);
$Idsal= utf8_decode($_GET['Idsal']);
$Idalu= utf8_decode($_GET['Idalu']);

$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres, Idesc, Foto FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row[Nombres];
    $Idescl=$row[Idesc];
    $foto=$row[Foto];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

<SCRIPT language=JavaScript>

function tick() {
  var hours, minutes, seconds, ap;
  var intHours, intMinutes, intSeconds;
  var today;
  today = new Date();
  intHours = today.getHours();
  intMinutes = today.getMinutes();
  intSeconds = today.getSeconds();

  switch(intHours){
       case 0:
           intHours = 12;
           hours = intHours+":";
           ap = "A.M.";
           break;
       case 12:
           hours = intHours+":";
           ap = "P.M.";
           break;
       case 24:
           intHours = 12;
           hours = intHours + ":";
           ap = "A.M.";
           break;
       default:    
           if (intHours > 12)
           {
             intHours = intHours - 12;
             hours = intHours + ":";
             ap = "P.M.";
             break;
           }
           if(intHours < 12)
           {
             hours = intHours + ":";
             ap = "A.M.";
           }
    }       
       

  if (intMinutes < 10) {
     minutes = "0"+intMinutes+":";
  } else {
     minutes = intMinutes+":";
  }

  if (intSeconds < 10) {
     seconds = "0"+intSeconds+" ";
  } else {
     seconds = intSeconds+" ";
  } 

  timeString = hours+minutes+seconds+ap;
  Clock.innerHTML = timeString;
  window.setTimeout("tick();", 100);
}

window.onload = tick;
</SCRIPT>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Caja <span> Kardex</span></h1>
		<p>Area de Pagos de Salario </p>
			</div>
			
			<div id="page" class="round">
			<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="caja.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>" title="" class="round">Área de Caja</a></li>
<li><a href="pagos.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>" title="" class="round active">Área de Pagos</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>


			<div id="wrapper2" class="round">
				<div id="sidebar" class="round">
						<h3>Alumnos</h3>
						<ul>
		   <li>Registro</li>
     <li>Actualizar</li>
     <li>Historial</li>
						</ul>


 <h3>Soporte</h3>
						<ul>
    <li>Soporte</li>
						</ul>
					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">

				<h2 align="center">	<a id=Clock style="FONT-SIZE: 40px; COLOR: GREEN; FONT-FAMILY: " class="current"></a></h2>

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

<p>Mensaje:<a style="color:red;"> ;]. <?php echo utf8_decode($men);
 ?> </a></p>

<?php

$dir = 'dat/usuarios/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='right'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?>


<div id="wrapper2" class="round">			
<div id="sidebar2" class="round">
<?php
include 'dat/cdb/db.php';
$Idesc = utf8_decode($_GET['Idesc']);

if($Idesc<=0)
$Idesc=$Idescl;

$resultado1=mysqli_query($db_connection, "SELECT Idesc, Escuela FROM escuelas WHERE  Estado=1 && Idesc='".$Idesc."' ORDER BY Idesc  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
   $Idesc=$row1[Idesc];
	  $Escuela=$row1[Escuela];
?> 
<h3><a style="color:orange;">  <?php echo $Escuela; ?></a></h3>
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>			

<h3><a href="pagos.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">Nuevo Pago <img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/> </a></h3>

<h3>Buscar Docente</h3>

<form action="pbusdoc.php" method="POST" >
      <input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
      <input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
    
<div>
<div>
<input type="text" name="cor" class="form-control" placeholder="Correo, Movil, Apellidos, Nombres" class="form-input" size="30" required>
<button type="submit"><img src="dat/ima/busca.png" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>

<?php
include 'dat/cdb/db.php';
$Iddoc= utf8_decode($_GET['Iddoc']);
$resultx=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Foto FROM docentes WHERE Iddoc = '".$Iddoc."' ");

if (mysqli_num_rows($resultx)>0)
{

while ($rowx =mysqli_fetch_array($resultx)){
    $nom=$rowx[Nombres];
    $ape=$rowx[Apellidos];
    $foto=$rowx[Foto];

$dir = 'dat/docentes/';
$foto=$dir.$foto;

 echo "	<div id='splash' align='right'><img src='".$foto."' alt='' width='200' height='100' class='round' align='center' /> </div>";

?> 
<center>	<a style="FONT-SIZE: 30px; COLOR: GREEN; FONT-FAMILY: " class="current">Docente: <?php echo $nom; ?> <?php echo $ape; ?> </a> </center>
<?php
}
}
mysqli_free_result($resultx);
mysqli_close($db_connection);
?>


<h3>Datos del Pago</h3>

<form action="ppagos.php" method="POST" >

<input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">

<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">

<input type="hidden" name="Iddoc"  value="<?php echo utf8_decode($_GET['Iddoc']); ?>">
    

<?php
include 'dat/cdb/db.php';
$Iddoc= utf8_decode($_GET['Iddoc']);
$result=mysqli_query($db_connection, "SELECT md.Asignadas Asi, m.Materia Mat, m.Costo Cos, md.Idmd Md, md.Idcic Cic, m.Idmat M FROM detallemd md, materias m, ciclos c WHERE md.Iddoc = '".$Iddoc."' && md.Idmat=m.Idmat && md.Idcic=c.Idcic && c.Estado=1 ");

if (mysqli_num_rows($result)>0)
{

while ($row =mysqli_fetch_array($result)){
    $asi=$row[Asi];
    $mat=$row[Mat];
    $cos=$row[Cos];
    $md=$row[Md];
    $cic=$row[Cic];
    $m=$row[M];

?> 

<input type="hidden" name="Idmd"  value="<?php echo $md; ?>">

<input type="hidden" name="Idcic"  value="<?php echo $cic; ?>">

<input type="hidden" name="Idmat"  value="<?php echo $m; ?>">

<div>
<div>
<input type="text" name="fol" class="form-control" placeholder="Folio" class="form-input" size="5">

<select name="can">
<option value="1">Una Semana</option>
<option selected="selected"  value="2">Dos Semanas</option>
<option value="3">Tres Semanas</option>
<option value="4">Cuatro Semanas</option>
</select>

<input type="text" name="asi" class="form-control" placeholder="Asignadas" class="form-input" size="5" value="<?php echo $asi; ?>">

<input type="text" name="mat" class="form-control" placeholder="Materia" class="form-input" size="30" value="<?php echo $mat; ?>">


<input type="text" name="cos" class="form-control" placeholder="Costo" class="form-input" size="5" value="<?php echo $cos; ?>" required>

<input type="text" name="des" class="form-control" placeholder="Descuento" class="form-input" size="5" required>


<button type="submit"><img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>


<?php
}
}
mysqli_free_result($result);
mysqli_close($db_connection);
?>

</form>

<?php
include 'dat/cdb/db.php';
$Iddoc = utf8_decode($_GET['Iddoc']);

$resultado6=mysqli_query($db_connection, "SELECT * FROM pagos WHERE  Estado=0 && Iddoc='".$Iddoc."' ");

if (mysqli_num_rows($resultado6)>0)
{			  
      while ($row6 =mysqli_fetch_array($resultado6)){
   $Idpag=$row6[Idpag];
   $fol=$row6[Folio];
   $asi=$row6[Asignada];
   $can=$row6[Cantidad];
   $mat=$row6[Materia];
   $cos=$row6[Costo];
   $imp=$row6[Importe];
   $des=$row6[Descuento];
   $sub=$row6[Subtotal];
   $tot=$row6[Total];
   $let=$row6[Letras];
?>
</br>
<?php echo $fol; ?> - 
<?php echo $asi; ?> - 
<?php echo $can; ?> - 
<?php echo $mat; ?> - 
<?php echo $cos; ?> - 
<?php echo $imp; ?> - 
<?php echo $des; ?> - 
<?php echo $sub; ?> - 
<?php echo $tot; ?>
</br>
<?php echo $let; ?>
   
<button type="submit"><a href="pborpag.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Iddoc=<?php echo $Iddoc; ?>&Idpag=<?php echo $Idpag; ?>"> <img src="dat/ima/borra.png" alt="" width="40" height="40"  class="round"/> </a></button>


<?php
      }
}
mysqli_free_result($resultado6);
mysqli_close($db_connection);
 ?>				

<form action="imprimire.php" method="POST" >

<input type="hidden" name="Idusu"   value="<?php echo utf8_decode($_GET['Idusu']); ?>">
<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">
<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">

    
<div>
<div>
<button type="submit"><img src="dat/ima/imp.png" alt="" width="40" height="40"  class="round"/></button>
</div>
</div>
</form>


<h3>Actualizar tú perfil</h3>					
<ul>
<li align="center"><a href="actusu2.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">
<img src="dat/ima/tipo.png" alt="" width="250" height="200" class="round" /></a> 
</li>
<li align="center"><a href="actusu2.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>">Actualiza tú perfil</a></li>					
</ul>

<div id="splash" align="center">
<img src="dat/ima/kardexb.png" alt="" width="600" height="300" class="round" align="center" />

<!-- End Sidebar -->
</div>
</div>
					<!-- End Content -->
					</div>
					<div style="clear: both"></div>
				<!-- End Wrapper 2 -->
				</div>
			<!-- End Page -->
			</div>
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.
</div>

</body>
</html>
