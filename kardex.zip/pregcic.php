<?php

include 'dat/cdb/db.php';

$cic = $_REQUEST['cic'];
$sis = $_REQUEST['sis'];

if($sis==1)
$sis="ESCOLARIZADO";
if($sis==2)
$sis="SEMIESCOLARIZADO";
if($sis==3)
$sis="EN LÍNEA";
  

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


if($Idesc>0 && $Idcar>0)
{

$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO ciclos (Ciclo, Sistema, Estado, Idcar) VALUES ('".$cic."', '".$sis."', 1, '".$Idcar."')";

$retry_value = mysqli_query($db_connection,$insert_value);


$result1=mysqli_query($db_connection, "SELECT Idcic FROM  ciclos WHERE Ciclo = '".$cic."' ");


while ($row1 =mysqli_fetch_array($result1)) {
   	 $Idcic=$row1[Idcic];
   }

$men="Agregó el ciclo";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&men='.$men.'');


 } else {

header('Location: index.php?cic='.$cic.'');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_free_result($result1);

mysqli_close($db_connection);

}else {

$men="Seleccionar o Agregar La carrera";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');

}
?>
