<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Materias al Docente</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idmat = utf8_decode($_GET['Idmat']);
$Idsal = utf8_decode($_GET['Idsal']);
$Idgra = utf8_decode($_GET['Idgra']);
$Iddoc = utf8_decode($_GET['Iddoc']);

$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row[Nombres];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Registro de las <span>Materias</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>



<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>


				<div id="wrapper2" class="round">

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>



			</ul>				

						

		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	



<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>


<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>



	<div id="splash" align="center">

<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />

				</div>



<h3>Carrera</h3>					

<ul>



<?php
include 'dat/cdb/db.php';
$Idcar = utf8_decode($_GET['Idcar']);
$resultado2=mysqli_query($db_connection, "SELECT Carrera FROM carreras WHERE  Idcar='".$Idcar."' ");

if (mysqli_num_rows($resultado2)>0)
{			  

while ($row2 =mysqli_fetch_array($resultado2))
	  {
	  $Carrera=$row2[Carrera];
?> 

	<li><a><?php echo $Carrera; ?></a></li>

<?php

      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>

	

<h3>Grado - Materia - Horas Clase</h3>


<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);

$resultado3=mysqli_query($db_connection, "SELECT mat.Idmat Idmat, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idgra Idgra FROM materias mat WHERE mat.Idcar='".$Idcar."' ORDER BY mat.Idgra ");

if (mysqli_num_rows($resultado3)>0)
{			  

      while ($row3 =mysqli_fetch_array($resultado3))
	  {
     $Idmatz=$row3[Idmat];
     $mz=$row3[Materia];
     $hcz=$row3[HorasClase];
     $gra=$row3[Idgra];
	    $Idgraz=$gra;

if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";


 



?> 

<a href="regrmd.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmatz; ?>&Idgra=<?php echo $Idgraz; ?>&Iddoc=<?php echo $Iddoc; ?>&nh=<?php echo $hcz; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $gra; ?>

<?php echo $mz; ?>

 - 

<?php echo $hcz; ?>



</br>



<?php

      }

}

mysqli_free_result($resultado3);

mysqli_close($db_connection);

 ?>				






<h3>Docentes</h3>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idgra = utf8_decode($_GET['Idgra']);


$nh = utf8_decode($_GET['nh']);



$resultado4=mysqli_query($db_connection, "SELECT Iddoc, Nombres, Apellidos FROM docentes WHERE Idesc='".$Idesc."' ORDER BY Apellidos ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

     $Iddoc=$row4[Iddoc];

     $nom=$row4[Nombres];

     $ape=$row4[Apellidos];

?> 



<a href="regrmd.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Iddoc=<?php echo $Iddoc; ?>&nh=<?php echo $nh; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $nom; ?>

  

<?php echo $ape; ?>



</br>



<?php

      }

}

mysqli_free_result($resultado4);

mysqli_close($db_connection);

 ?>				

					

<h3>Asignación de la Materia al Docente</h3>

						<ul>

<li> 

<?php

include 'dat/cdb/db.php';



$Idmat = utf8_decode($_GET['Idmat']);



$resultado5=mysqli_query($db_connection, "SELECT  Materia, HorasClase FROM materias WHERE Idmat='".$Idmat."' ");



if (mysqli_num_rows($resultado5)>0)

{			  

      while ($row5 =mysqli_fetch_array($resultado5)) 

	  {

     $m5=$row5[Materia];

     $hc5=$row5[HorasClase];

?> 



<?php echo $m5; ?>

 - 

<?php echo $hc5; ?>

 - 





<?php

      }

}

mysqli_free_result($resultado5);

mysqli_close($db_connection);

 ?>





<?php

include 'dat/cdb/db.php';



$Iddoc = utf8_decode($_GET['Iddoc']);



$resultado6=mysqli_query($db_connection, "SELECT  Nombres, Apellidos FROM docentes WHERE Iddoc='".$Iddoc."' ");



if (mysqli_num_rows($resultado6)>0)

{			  

      while ($row6 =mysqli_fetch_array($resultado6)) 

	  {

     $n6=$row6[Nombres];

     $a6=$row6[Apellidos];

?> 



<?php echo $n6; ?>

  

<?php echo $a6; ?>





<?php

      }

}

mysqli_free_result($resultado6);

mysqli_close($db_connection);

 ?>	

</li> 







<li> 

        <p>

            <form action="pregrmd.php" method="POST">

               



<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">



<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">



<input type="hidden" name="Idcar" value="<?php echo utf8_decode($_GET['Idcar']); ?>">



<input type="hidden" name="Idcic" value="<?php echo utf8_decode($_GET['Idcic']); ?>">



<input type="hidden" name="Idmat" value="<?php echo utf8_decode($_GET['Idmat']); ?>">



<input type="hidden" name="Idgra" value="<?php echo utf8_decode($_GET['Idgra']); ?>">



<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">



<input type="hidden" name="nh" value="<?php echo utf8_decode($_GET['nh']); ?>">



                <div>

                    <div>

                        <button type="submit">¡Registrar!</button>

                                   </div>

                </div>

            </form>



	</li>

</ul> 



<h3>Actualizar la Materia al Docente</h3>



<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Iddoc = utf8_decode($_GET['Iddoc']);



$resultado7=mysqli_query($db_connection, "SELECT det.Idmd Idmd, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idmat Idmat, mat.Idgra Idgra, doc.Nombres Nom, doc.Apellidos Ape FROM materias mat, docentes doc, detallemd det WHERE  mat.Idmat=det.Idmat && doc.Iddoc=det.Iddoc &&  doc.Iddoc='".$Iddoc."' ORDER BY det.Idmd ");



if (mysqli_num_rows($resultado7)>0)

{			  

      while ($row7 =mysqli_fetch_array($resultado7)) 

	  {



     $Idmdj=$row7[Idmd];
     $Idmatj=$row7[Idmat];
     $mz=$row7[Materia];
     $hcj=$row7[HorasClase];
     $Idgraj=$row7[Idgra];

$gra=$Idgraj; 

if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";




	    $gz=$gra;

     $nj=$row7[Nom];

     $aj=$row7[Ape];



?> 



<a href="regrmd.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idgra=<?php echo $Idgraj; ?>&Idmat=<?php echo $Idmatj; ?>&Iddoc=<?php echo $Iddoc; ?>&hc=<?php echo $hcj; ?>&Idmd=<?php echo $Idmdj; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $gz; ?>

 - 

<?php echo $mz; ?>

 - 

<?php echo $hcz; ?>

 - 

<?php echo $nj; ?>

 - 

<?php echo $aj; ?>



<a href="pborrmd.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idgra=<?php echo $Idgraj; ?>&Idmat=<?php echo $Idmatj; ?>&Iddoc=<?php echo $Iddoc; ?>&hc=<?php echo $hcj; ?>&Idmd=<?php echo $Idmdj; ?>"> <img src="dat/ima/borra.png" alt="" width="40" height="40"  class="round"/></a>

</br>



<?php

      }

}

mysqli_free_result($resultado7);

mysqli_close($db_connection);

 ?>				







<form action="pactrmd.php" method="POST">


<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">


<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">



<input type="hidden" name="Idcar" value="<?php echo utf8_decode($_GET['Idcar']); ?>">

<input type="hidden" name="Idmat" value="<?php echo utf8_decode($_GET['Idmat']); ?>">

<input type="hidden" name="Idcic" value="<?php echo utf8_decode($_GET['Idcic']); ?>">

<input type="hidden" name="Idgra" value="<?php echo utf8_decode($_GET['Idgra']); ?>">

<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">



<input type="hidden" name="Idmd" value="<?php echo utf8_decode($_GET['Idmd']); ?>">





<div>

<div>

<select name="mat">

<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);



$resultado3=mysqli_query($db_connection, "SELECT mat.Idmat Idmat, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idgra Idgra FROM materias mat WHERE mat.Idcar='".$Idcar."' ORDER BY mat.Idgra ");



if (mysqli_num_rows($resultado3)>0)

{			  

      while ($row3 =mysqli_fetch_array($resultado3)) 

	  {



     $Idmatz=$row3[Idmat];

     $mz=$row3[Materia];

     $hcz=$row3[HorasClase];

     $Idgraz=$row3[Idgra];

	    $gra=$Idgraz;


if($gra==1)


$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";






?> 



 <option value="<?php echo $Idmatz; ?>

" selected>

<?php echo $gra; ?>

 - 

<?php echo $mz; ?>

 - 

<?php echo $hcz; ?>

</option> 



<?php

      }

}

mysqli_free_result($resultado3);

mysqli_close($db_connection);

 ?>



  </select>

</div>

</div>



                <div>

                    <div>

                        <button type="submit">¡Actualizar!</button>

                                   </div>

                </div>

            </form>





					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>

		

		



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>

	



	

</html>


