<?php

include 'dat/cdb/db.php';

$fec = $_REQUEST['fec'];
$tem = $_REQUEST['tem'];
$hum = $_REQUEST['hum'];
$hor = $_REQUEST['hor'];
$not = $_REQUEST['not'];
$dia = $_REQUEST['dia'];

$Idusu = $_REQUEST['Idusu'];
$Idemp = $_REQUEST['Idemp'];
$Idinc = $_REQUEST['Idinc'];


if($tem<37.7 && $dia < 19)
$nott="verificar los focos porque deben de estar encendidos ambos, y en caso de estar encendidos pruebe con colocar unos de mayor capacidad, vea que la incubadora se encuentre dentro de una habitación techada";

if($tem>38.0  && $dia < 19)
$nott="verificar los focos porque deben de estar apagados ambos, y en caso de estar apagados, verificar el ventilador debe de estar encendido vea que la incubadora se encuentre en lugar techado";

if($tem<38.0  && $dia > 18)
$nott="verificar los focos porque deben de estar encendidos ambos, y en caso de estar encendidos pruebe con insertar unos de mayor capacidad vea que la incubadora se encuentre en lugar techado";

if($tem>38.0  && $dia > 18)
$nott="verificar los focos porque deben de estar apagados ambos, y en caso de estar apagados verificar el ventilador debe de estar encendido vea que la incubadora se encuentre en lugar techado";

if($hum<60 && $dia  < 19)
$noth="verificar los contenedores de agua porque deben de estar con 1pulgada de agua ambos, y en caso de estar con el agua al limite pruebe con insertar un traste de agua mas en el centro con la misma capacidad y verificar el ventilador debe de estar encendido";

if($hum>70 && $dia < 19)
$noth="verificar los contenedores de agua porque deben de estar con 1pulgada de agua ambos, y en caso de no estar asi colocar el agua al limite o pruebe con quitar un traste  y colocar unos solo en el centro mientras baja la humedad ademas verificar que el ventilador debe de estar encendido";

if($hum<80 && $dia > 19)
$noth="verificar los contenedores de agua porque deben de estar con 1pulgada de agua los tres y verificar el ventilador debe de estar encendido";

if($hum>90 && $dia > 19)
$noth="verificar los contenedores de agua porque deben de estar con 1pulgada de agua los tres y verificar el ventilador debe de estar encendido puede retirar un traste mientras baja la humedad";


$not .= " temperatura: ".$nott." humedad:".$noth;

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO itinerarios (Dia, Fecha, Temperatura, Humedad, Hora, Nota, Idinc) VALUES ('".$dia."', '".$fec."', '".$tem."', '".$hum."', '".$hor."', '".$not."', '".$Idinc."')";

$retry_value = mysqli_query($db_connection,$insert_value);


$result1=mysqli_query($db_connection, "SELECT Iditi FROM  itinerarios WHERE Fecha = '".$fec."' ");


while ($row1 =mysqli_fetch_array($result1)) {
   	 $Iditi=$row1[Iditi];
   }


header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'&Idinc='.$Idinc.'&Iditi='.$Iditi.'');


 } else {

header('Location: index.php');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_free_result($result1);

mysqli_close($db_connection);
?>
