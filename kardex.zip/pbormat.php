<?php



include 'dat/cdb/db.php';



$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];

$Idcar = $_REQUEST['Idcar'];
$Idmat = $_REQUEST['Idmat'];


$resultado=mysqli_query($db_connection, "SELECT Idmat FROM materias WHERE Idmat= '".$Idmat."' ");

 

if (mysqli_num_rows($resultado)>0)

{



$delete_value = "DELETE FROM materias WHERE Idmat='".$Idmat."' ";



$retry_value = mysqli_query($db_connection,$delete_value);





$men="Borró la materia";



header('Location: regmat.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');




 } else {





$men="Seleccionar la materia";



header('Location: regmat.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');



}



mysqli_free_result($retry_value);

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>


