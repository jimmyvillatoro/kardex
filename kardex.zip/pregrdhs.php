<?php
include 'dat/cdb/db.php';

$nh = $_REQUEST['nh'];
$gra = $_REQUEST['gra'];
$hor = $_REQUEST['hor'];// Iddh

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idsal = $_REQUEST['Idsal'];
$Idgra = $_REQUEST['Idgra'];
$Iddoc = $_REQUEST['Iddoc'];

$Idmat = $_REQUEST['Idmat'];

//horario del docente

$resultado=mysqli_query($db_connection, "SELECT Dia, Horario FROM docentesh WHERE Iddh= '".$hor."' && Estado=1 ");

if (mysqli_num_rows($resultado)>0)
{

while ($row =mysqli_fetch_array($resultado)){
   	 $dia=$row[Dia];
    $horario=$row[Horario];
}

 } else {

$men="No se encuentra el horario disponible en el docente";

header('Location: regrdhs.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');
}



// materias asignadas al docente

$result=mysqli_query($db_connection, "SELECT Idmd, Horas, Asignadas FROM detallemd WHERE Iddoc= '".$Iddoc."' && Idmat= '".$Idmat."' && Idcic= '".$Idcic."'");


if (mysqli_num_rows($result)>0)
while ($rowx =mysqli_fetch_array($result))
{
   	 $I=$rowx[Idmd];
    $H=$rowx[Horas];
    $A=$rowx[Asignadas];
}

$N=$H-$A;
$AA=$A+1; //act de h asignadas


// mientras HC < Asignadas

if($A<$H)
{

//que el dia y hora no este en uso en el salon (detalleh)


{

$insert_value = "INSERT INTO detalleh (Horas, Dia, Horario,   Idmd, Iddh, Idsal) VALUES (1, '".$dia."', '".$horario."', '".$I."', '".$hor."', '".$Idsal."')";

$retry_value2 = mysqli_query($db_connection,$insert_value);

$update_value = "UPDATE docentesh SET  Estado=2 WHERE Iddh='".$hor."'";

$retry_value1 = mysqli_query($db_connection,$update_value);


$update_value = "UPDATE detallemd SET  Asignadas='".$AA."' WHERE Idmd='".$I."'";

$retry_value3 = mysqli_query($db_connection,$update_value);

$men="Agregó el Horario del Docente";

mysqli_free_result($retry_value1);
mysqli_free_result($retry_value2);
mysqli_free_result($retry_value3);

}

}


header('Location: regrdhs.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&gra='.$gra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');



mysqli_free_result($resultado);
mysqli_close($db_connection);
?>






