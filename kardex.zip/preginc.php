<?php

include 'dat/cdb/db.php';

$mod = $_REQUEST['mod'];
$can = $_REQUEST['can'];
$tip = $_REQUEST['tip'];
$des = $_REQUEST['des'];
$fec = $_REQUEST['fec'];
$hor = $_REQUEST['hor'];

$Idusu = $_REQUEST['Idusu'];
$Idemp = $_REQUEST['Idemp'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{


// en em modelo colocar cant huevos y serie para diferenciar

$insert_value = "INSERT INTO incubadoras (Modelo, Cantidad, Tipo, Descrip, Fecha, Hora, Estado, Idemp) VALUES ('".$mod."', '".$can."', '".$tip."', '".$des."', '".$fec."', '".$hor."',1, '".$Idemp."')";

$retry_value = mysqli_query($db_connection,$insert_value);


$result1=mysqli_query($db_connection, "SELECT Idinc FROM  incubadoras WHERE Modelo = '".$mod."' ");


while ($row1 =mysqli_fetch_array($result1)) {
   	 $Idinc=$row1[Idinc];
   }



header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'&Idinc='.$Idinc.'');


 } else {

header('Location: index.php');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_free_result($result1);

mysqli_close($db_connection);
?>
