<?php

include 'dat/cdb/db.php';



$dia = $_REQUEST['dia'];
$hi = $_REQUEST['hi'];
$hf = $_REQUEST['hf'];

$h= $hi.' - '.$hf;



$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];


date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());



$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu= '".$Idusu."' ");


if (mysqli_num_rows($resultado)>0)

{

$insert_value = "INSERT INTO escuelash (Dia, Inicioh, Finh, Horario, Idesc) VALUES ('".$dia."', '".$hi."', '".$hf."', '".$h."', '".$Idesc."')";



$retry_value = mysqli_query($db_connection,$insert_value);



$men="Agregó el Horario";


header('Location: reghor.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');



 } else {





$men="Su usuario no tiene acceso";



header('Location: reghor.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&men='.$men.'');

}



mysqli_free_result($retry_value);

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

