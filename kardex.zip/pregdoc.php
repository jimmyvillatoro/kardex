<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];


$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Correo = '".$cor."' && Idesc='".$Idesc."' ");
 

if (mysqli_num_rows($resultado)>0)
{
header('Location: index.php?nom='.$nom.'& mov='.$mov.'&cor='.$cor.'');
 } else {


$insert_value = "INSERT INTO docentes (Nombres, Apellidos, Correo, Movil, Pass, Fecha, Estado, Idesc) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."', '".$date."', 1, '".$Idesc."' )";

$retry_value = mysqli_query($db_connection,$insert_value);


$cuerpo='Nombre: '. $nom.'  Movil: '.$mov.'  Correo: '.$cor;

mail('soporte@yaprendo.com','Un Docente dale seguimiento->',$cuerpo,'Equipo Kardex');

$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes  WHERE Nombres = '".$nom."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $Iddoc=$row[Iddoc];
   }

$men="Agregó al docente";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&men='.$men.'');

}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
