﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml">	<head>		<title>Acerca de</title>		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />		<meta name="keywords" content="" />		<meta name="description" content="" />		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />	</head>		<body>		<div id="wrapper">					<div id="logo">				<h1>kardex.<span>yaprendo.com</span></h1>				<p>educar en casa</p>			</div>						<div id="page" class="round">						<div id="menu" class="round">			<ul><li><a href="index.html" title="" class="round">Inicio</a></li><li><a href="sesion.php" title="" class="round">Acceso</a></li><li><a href="contacto.php" title="" class="round active">Acerca de</a></li><li><a href="soporte.php" title="" class="round">Soporte</a></li>			</ul>						</div>								<div id="wrapper2" class="round">									<div id="sidebar" class="round">										<h3>Índice</h3>			<ul><li><a href="index.html" title="" class="round active">Inicio</a></li><li><a href="sesion.php" title="" class="round">Acceso</a></li><li><a href="contacto.php" title="" class="round">Acerca de</a></li><li><a href="soporte.php" title="" class="round">Soporte</a></li>			</ul>																       								<!-- End Sidebar -->									</div>						<div id="content" class="round">					<div id="splash" align="center"><img src="dat/ima/kardexb.png" alt="" width="600" height="300" class="round" align="center" />				</div>							<h3>Contactos</h3>						<ul>    <li>Ventas</li>    <li>ventas@yaprendo.com</li>		  	<li>Soporte</li>    <li>soporte@yaprendo.com</li>          						</ul>							<!-- End Content -->					</div>								<div style="clear: both"></div>							<!-- End Wrapper 2 -->				</div>							<!-- End Page -->			</div>				<!-- End Wrapper -->		</div>	


<div id="wrapper" class="round">

						<div id="page" class="round"style="text-align: justify;"  >

	<div id="splash">
					

<img src="dat/ima/infk1.jpg" alt="" width="960" height="750" class="round" />

<img src="dat/ima/infk2.jpg" alt="" width="960" height="750" class="round" />

<img src="dat/ima/infk3.jpg" alt="" width="960" height="750" class="round" />

<img src="dat/ima/infk4.jpg" alt="" width="960" height="750" class="round" />

<img src="dat/ima/infk5.jpg" alt="" width="960" height="750" class="round" />

<img src="dat/ima/infk6.jpg" alt="" width="960" height="750" class="round" />


			
			<!-- End Page -->
			</div>
					<!-- End wrapper -->
					</div>


	<div id="footer">			<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>		</div>				<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>		</html>