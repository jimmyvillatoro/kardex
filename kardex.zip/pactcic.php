<?php



include 'dat/cdb/db.php';





$cic = $_REQUEST['cic'];

$sis = $_REQUEST['sis'];

$est = $_REQUEST['est'];



if($est=="ACTIVO")

$est=1;

if($est=="INACTIVO")

$est=0;


if($sis==1)

$sis="ESCOLARIZADO";

if($sis==2)

$sis="SEMIESCOLARIZADO";

if($sis==3)

$sis="EN LÍNEA";




$Idesc = $_REQUEST['Idesc'];

$Idusu = $_REQUEST['Idusu'];

$Idcar = $_REQUEST['Idcar'];

$Idcic = $_REQUEST['Idcic'];



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());




$update_value ="UPDATE ciclos SET Ciclo='".$cic."', Sistema='".$sis."', Estado='".$est."' WHERE Idcic='".$Idcic."' ";



$retry_value = mysqli_query($db_connection,$update_value);





$men="Ciclo actualizado";


header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&men='.$men.'');







mysqli_free_result($retry_value);



mysqli_close($db_connection);

?>


