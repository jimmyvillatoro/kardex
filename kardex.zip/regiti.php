<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Itinerario</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />



<?php
include 'dat/cdb/db.php';

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$Idusu = utf8_decode($_GET['Idusu']);
$Idemp = utf8_decode($_GET['Idemp']);
$Idinc = utf8_decode($_GET['Idinc']);
$Iditi = utf8_decode($_GET['Iditi']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Registro del <span>Itinerario</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>&Iditi=<?php echo $Iditi; ?>" title="" class="round active">Atrás</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>
				

				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>				
						

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>


	<div id="splash" align="center">
<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />
				</div>

<h3>Granja</h3>					
<ul>

<?php
include 'dat/cdb/db.php';
$Idemp = utf8_decode($_GET['Idemp']);

$resultado1=mysqli_query($db_connection, "SELECT Empresa FROM empresas WHERE  Estado=1 && Idemp='".$Idemp."' ORDER BY Idemp  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {

	  $Empresa=$row1[Empresa];

?> 
	<li><a><?php echo $Empresa; ?></a></li>
 
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>				
</ul>


<h3>Incubadora</h3>					
<ul>

<?php
include 'dat/cdb/db.php';
$Idinc = utf8_decode($_GET['Idinc']);

$resultado2=mysqli_query($db_connection, "SELECT Modelo FROM incubadoras WHERE  Idinc='".$Idinc."' ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {

	  $Modelo=$row2[Modelo];

?> 
	<li><a><?php echo $Modelo; ?></a></li>
 
<?php
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>				
</ul>
	
<h3>Registro del Itinerario</h3>
						<ul>
<li> 

        <p>
            <form action="pregiti.php" method="POST">
                <p align="justify"> Los siguientes datos son necesarios para nosotros.</p>

<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">

<input type="hidden" name="Idemp" value="<?php echo utf8_decode($_GET['Idemp']); ?>"> 

<input type="hidden" name="Idinc" value="<?php echo utf8_decode($_GET['Idinc']); ?>"> 

<div>
  <div>
 <select name="dia">
  <option value="0" selected>0</option> 
  <option value="1" >1</option>
  <option value="2">2</option>
   <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
     <option value="6">6</option>
      <option value="7">7</option>
   <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
     <option value="11">11</option>
      <option value="12">12</option>
   <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
     <option value="16">16</option>
      <option value="17">17</option>
   <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
     <option value="21">21</option>
  </select>
                    </div>
                </div>
               

                <div>
                    <div>

                        <input type="date" name="fec" class="form-control" placeholder="Fecha" class="form-input" size="20"
 value="<?php echo $date; ?>" required>
                    </div>
                </div>

<div>
  <div>
 <select name="tem">
Temperatura
<option value="34.0">34.0°</option>
<option value="34.1">34.1°</option>
<option value="34.2">34.2°</option>
<option value="34.3">34.3°</option>
<option value="34.4">34.4°</option>
<option value="34.5">34.5°</option>
<option value="34.6">34.6°</option>
<option value="34.7">34.7°</option>
<option value="34.8">34.8°</option>
<option value="34.9">34.9°</option>
<option value="35.0">35.0°</option>
<option value="35.1">35.1°</option>
<option value="35.2">35.2°</option>
<option value="35.3">35.3°</option>
<option value="35.4">35.4°</option>
<option value="35.5">35.5°</option>
<option value="35.6">35.6°</option>
<option value="35.7">35.7°</option>
<option value="35.8">35.8°</option>
<option value="35.9">35.9°</option>
<option value="36.0">36.0°</option>
<option value="36.1">36.1°</option>
<option value="36.2">36.2°</option>
<option value="36.3">36.3°</option>
<option value="36.4">36.4°</option>
<option value="36.5">36.5°</option>
<option value="36.6">36.6°</option>
<option value="36.7">36.7°</option>
<option value="36.8">36.8°</option>
<option value="36.9">36.9°</option>
<option value="37.0">37.0°</option>
<option value="37.1">37.1°</option>
<option value="37.2">37.2°</option>
<option value="37.3">37.3°</option>
<option value="37.4">37.4°</option>
<option value="37.5">37.5°</option>
<option value="37.6">37.6°</option>
<option value="37.7" selected>37.7°</option>
<option value="37.8">37.8°</option>
<option value="37.9">37.9°</option>
<option value="38.0">38.0°</option>
<option value="38.1">38.1°</option>
<option value="38.2">38.2°</option>
<option value="38.3">38.3°</option>
<option value="38.4">38.4°</option>
<option value="38.5">38.5°</option>
<option value="38.6">38.6°</option>
<option value="38.7">38.7°</option>
<option value="38.8">38.8°</option>
<option value="38.9">38.9°</option>
<option value="39.0">39.0°</option>
<option value="39.1">39.1°</option>
<option value="39.2">39.2°</option>
<option value="39.3">39.3°</option>
<option value="39.4">39.4°</option>
<option value="39.5">39.5°</option>
<option value="39.6">39.6°</option>
<option value="39.7">39.7°</option>
<option value="39.8">39.8°</option>
<option value="39.9">39.9°</option>
<option value="40.0">40.0°</option>
  </select>
                    </div>
                </div>
<div>
  <div>
 <select name="hum">
Humedad
<option value="1">1%</option>
<option value="2">2%</option>
<option value="3">3%</option>
<option value="4">4%</option>
<option value="5">5%</option>
<option value="6">6%</option>
<option value="7">7%</option>
<option value="8">8%</option>
<option value="9">9%</option>
<option value="10">10%</option>
<option value="11">11%</option>
<option value="12">12%</option>
<option value="13">13%</option>
<option value="14">14%</option>
<option value="15">15%</option>
<option value="16">16%</option>
<option value="17">17%</option>
<option value="18">18%</option>
<option value="19">19%</option>
<option value="20">20%</option>
<option value="21">21%</option>
<option value="22">22%</option>
<option value="23">23%</option>
<option value="24">24%</option>
<option value="25">25%</option>
<option value="26">26%</option>
<option value="27">27%</option>
<option value="28">28%</option>
<option value="29">29%</option>
<option value="30">30%</option>
<option value="31">31%</option>
<option value="32">32%</option>
<option value="33">33%</option>
<option value="34">34%</option>
<option value="35">35%</option>
<option value="36">36%</option>
<option value="37">37%</option>
<option value="38">38%</option>
<option value="39">39%</option>
<option value="40">40%</option>
<option value="41">41%</option>
<option value="42">42%</option>
<option value="43">43%</option>
<option value="44">44%</option>
<option value="45">45%</option>
<option value="46">46%</option>
<option value="47">47%</option>
<option value="48">48%</option>
<option value="49">49%</option>
<option value="50">50%</option>
<option value="51">51%</option>
<option value="52">52%</option>
<option value="53">53%</option>
<option value="54">54%</option>
<option value="55">55%</option>
<option value="56">56%</option>
<option value="57">57%</option>
<option value="58">58%</option>
<option value="59">59%</option>
<option value="60"selected>60%</option>
<option value="61">61%</option>
<option value="62">62%</option>
<option value="63">63%</option>
<option value="64">64%</option>
<option value="65">65%</option>
<option value="66">66%</option>
<option value="67">67%</option>
<option value="68">68%</option>
<option value="69">69%</option>
<option value="70">70%</option>
<option value="71">71%</option>
<option value="72">72%</option>
<option value="73">73%</option>
<option value="74">74%</option>
<option value="75">75%</option>
<option value="76">76%</option>
<option value="77">77%</option>
<option value="78">78%</option>
<option value="79">79%</option>
<option value="80">80%</option>
<option value="81">81%</option>
<option value="82">82%</option>
<option value="83">83%</option>
<option value="84">84%</option>
<option value="85">85%</option>
<option value="86">86%</option>
<option value="87">87%</option>
<option value="88">88%</option>
<option value="89">89%</option>
<option value="90">90%</option>
<option value="91">91%</option>
<option value="92">92%</option>
<option value="93">93%</option>
<option value="94">94%</option>
<option value="95">95%</option>
<option value="96">96%</option>
<option value="97">97%</option>
<option value="98">98%</option>
<option value="99">99%</option>
<option value="100">100%</option>
  </select>
                    </div>
                </div>
               

<div>
                    <div>

                        <input type="time" name="hor" class="form-control" placeholder="Hora" class="form-input" size="20"
 value="<?php echo $time; ?>" required>
                    </div>
                </div>

<div>
                    <div>
                     <div>
<textarea name="not" rows="4" cols="40" placeholder="Nota"></textarea>
                    </div>
                </div>
               

                <div>
                    <div>
                        <button type="submit">¡Registrar!</button>
                                   </div>
                </div>
            </form>



					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
