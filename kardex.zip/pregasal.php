<?php

include 'dat/cdb/db.php';


$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];

$Idcar = $_REQUEST['Idcar'];

$Idcic = $_REQUEST['Idcic'];

$Idsal = $_REQUEST['Idsal'];

$Idalu = $_REQUEST['Idalu'];



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());



$update_value ="UPDATE alumnos SET Idcar='".$Idcar."', Idcic='".$Idcic."', Idsal='".$Idsal."' WHERE Idalu='".$Idalu."' ";



$retry_value = mysqli_query($db_connection,$update_value);





$men="Actualizó al Alumno";



header('Location: regasal.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idsal='.$Idsal.'&men='.$men.'');




mysqli_free_result($retry_value);

mysqli_close($db_connection);

?>



