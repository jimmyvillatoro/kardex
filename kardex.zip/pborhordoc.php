<?php

include 'dat/cdb/db.php';

$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Iddoc = $_REQUEST['Iddoc'];
$Iddh  = $_REQUEST['Iddh'];


$resultado=mysqli_query($db_connection, "SELECT Iddh FROM docentesh WHERE Iddh= '".$Iddh."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$delete_value = "DELETE FROM docentesh WHERE Iddh='".$Iddh."' && Estado=1 ";

$retry_value = mysqli_query($db_connection,$delete_value);

$men="Borró el horario del docente";


header('Location: reghordoc.php?Iddoc='.$Iddoc.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&men='.$men.'');

 } else {

$men="Seleccionar el horario";

header('Location: reghordoc.php?Iddoc='.$Iddoc.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&men='.$men.'');
}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
