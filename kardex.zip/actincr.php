<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Actualizar</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idemp = utf8_decode($_GET['Idemp']);
$Idinc = utf8_decode($_GET['Idinc']);
$Iditi = utf8_decode($_GET['Iditi']);
$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");
while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row[Nombres];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Actualizar la <span>Incubadora</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>&Iditi=<?php echo $Iditi; ?>" title="" class="round active">Atrás</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>

				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>				

	
		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

<?php
include 'dat/cdb/db.php';

$Idinc = utf8_decode($_GET['Idinc']);
$result=mysqli_query($db_connection, "SELECT Resultado, Nota FROM incubadoras WHERE Idinc = '".$Idinc."' ");

while ($row1 =mysqli_fetch_array($result)) {
   	 $res=$row1[Resultado];
    $not=$row1[Nota];

   }
mysqli_free_result($result);
mysqli_close($db_connection);
?>

	<div id="splash" align="center">
<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />
				</div>
	
<h3>Actualizar la Incubadora</h3>
						<ul>
<li> 

        <p>
            <form action="pactincr.php" method="POST">
                <p align="justify"> Los siguientes datos son necesarios para nosotros.</p>

<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">
 
<input type="hidden" name="Idemp" value="<?php echo utf8_decode($_GET['Idemp']); ?>">


<input type="hidden" name="Idinc" value="<?php echo utf8_decode($_GET['Idinc']); ?>">

                <div>
                    <div>

                        <input type="text" name="res" class="form-control" placeholder="Resultados" class="form-input" size="20" value="<?php echo $res; ?>"
 required>
                    </div>
                    </div>
                    <div>
                    <div>

<textarea name="not" rows="4" cols="40" placeholder="Nota"> <?php echo $not; ?></textarea>
               
                    </div>
                </div>

                <div>
                    <div>
                        <button type="submit">¡Actualizar!</button>
                                   </div>
                </div>
            </form>

					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
	

</html>
