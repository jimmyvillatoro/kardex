<?php



include 'dat/cdb/db.php';



$gra = $_REQUEST['gra'];
$gram = $_REQUEST['gra'];

$mat = $_REQUEST['mat'];

$hor = $_REQUEST['hor'];

$cos = $_REQUEST['cos'];


$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];

$Idcar = $_REQUEST['Idcar'];





if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";



date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());





$resultado=mysqli_query($db_connection, "SELECT Idgra FROM grados WHERE Grado= '".$gra."' && Idcar='".$Idcar."' ");



if (mysqli_num_rows($resultado)<=0)

{



$insert_value = "INSERT INTO grados (Grado, Costo, Idgram, Idcar) VALUES ('".$gra."', 0, '".$gram."', '".$Idcar."')";



$retry_value = mysqli_query($db_connection,$insert_value);

}


$result1=mysqli_query($db_connection, "SELECT Idgra FROM grados WHERE Grado = '".$gra."' && Idcar='".$Idcar."' ");



while ($row1 =mysqli_fetch_array($result1))
   	 $Idgra=$row1[Idgra];


$insert_value = "INSERT INTO materias (Materia, HorasClase, Costo, Idgra, Idcar) VALUES ('".$mat."', '".$hor."', '".$cos."', '".$gram."', '".$Idcar."')";



$retry_value2 = mysqli_query($db_connection,$insert_value);


$result2=mysqli_query($db_connection, "SELECT Idmat FROM  materias WHERE Materia = '".$mat."' && Idcar='".$Idcar."' ");


while ($row2 =mysqli_fetch_array($result2))
   	 $Idmat=$row2[Idmat];


$men="Agregó la Materia ".$mat;

header('Location: regmat.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idmat='.$Idmat.'&men='.$men.'');



mysqli_free_result($retry_value);
mysqli_free_result($retry_value2);
mysqli_free_result($resultado);
mysqli_free_result($result1);
mysqli_free_result($result2);
mysqli_close($db_connection);
?>






