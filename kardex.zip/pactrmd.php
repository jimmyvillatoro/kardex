<?php

include 'dat/cdb/db.php';





$nh = $_REQUEST['nh'];



$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idmat = $_REQUEST['Idmat'];
$Idgra = $_REQUEST['Idgra'];
$Iddoc = $_REQUEST['Iddoc'];
$Idmd  = $_REQUEST['Idmd'];
$mat = $_REQUEST['mat'];

$resultado=mysqli_query($db_connection, "SELECT Idesc FROM escuelas WHERE Idesc= '".$Idesc."' ");

if (mysqli_num_rows($resultado)>0)
{

$resultado=mysqli_query($db_connection, "SELECT Idcar FROM carreras WHERE Idcar= '".$Idcar."' ");

if (mysqli_num_rows($resultado)>0)
{


$resultado=mysqli_query($db_connection, "SELECT Iddoc FROM docentes WHERE Iddoc= '".$Iddoc."' ");

if (mysqli_num_rows($resultado)>0)
{


$resultado=mysqli_query($db_connection, "SELECT Idcic FROM ciclos WHERE Idcic= '".$Idcic."' ");

if (mysqli_num_rows($resultado)>0)
{


$resultado=mysqli_query($db_connection, "SELECT Idmat FROM materias WHERE Idmat= '".$Idmat."' ");

if (mysqli_num_rows($resultado)>0)
{



$resultado3=mysqli_query($db_connection, "SELECT mat.Idmat Idmat, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idgra Idgra FROM materias mat WHERE mat.Idcar='".$Idcar."' && mat.Idmat='".$mat."' ORDER BY mat.Idgra ");



if (mysqli_num_rows($resultado3)>0)

{			  

      while ($row3 =mysqli_fetch_array($resultado3)) 

	  {

     $Idmatz=$row3[Idmat];
     $mz=$row3[Materia];
     $hcz=$row3[HorasClase];
     $Idgraz=$row3[Idgra];


$gra=$Idgraz;

if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)
$gra="DOCEAVO";



	    $gz=$gra;

      }

}





$update_value = "UPDATE detallemd SET  Horas='".$hcz."',  Idmat='".$Idmatz."'  WHERE Idmd='".$Idmd."'";



$retry_value = mysqli_query($db_connection,$update_value);



$men="Actualizó la materia al docente";


header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');



 } else {

$men="Seleccionar la materia";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}


}else {

$men="Seleccionar el ciclo";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');
}


 } else {

$men="Seleccionar el docente";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}



 } else {

$men="Seleccionar la carrera";

header('Location: regrmd.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}



 } else {

$men="Seleccionar la escuela";

header('Location: usuarios.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Iddoc='.$Iddoc.'&men='.$men.'');

}


mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_free_result($resultado3);
mysqli_close($db_connection);
?>



