<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Calificaciones</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';





$Idalu = utf8_decode($_GET['Idalu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idsal = utf8_decode($_GET['Idsal']);

$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos FROM alumnos WHERE Idalu = '".$Idalu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row[Nombres];
     $Apellidos=$row[Apellidos];
    
   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Historial de <span>Calificaciones</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="alumnos.php?Idalu=<?php echo $Idalu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>" title="" class="round active">Atrás</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>



				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>



		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	

<p>Alumno:<a style="color:orange;"> <?php echo $Nombres; ?> <?php echo $Apellidos; ?></a></p>




<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>



	<div id="splash" align="center">

<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />

				</div>


          

<h3>Calificaciones</h3>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idsal = utf8_decode($_GET['Idsal']);

$Idalu = utf8_decode($_GET['Idalu']);

$Iddoc = utf8_decode($_GET['Iddoc']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idgra = utf8_decode($_GET['Idgra']);





$resultado4=mysqli_query($db_connection, "SELECT alu.Idalu, alu.Nombres, alu.Apellidos, cal.Idcal, cal.Tarea, cal.Trabajo, cal.Examen, cal.Total,  cal.Faltas, cal.Nota, mat.Materia FROM alumnos alu, calificaciones cal, materias mat WHERE alu.Idesc='".$Idesc."' && alu.Idcar='".$Idcar."' && alu.Idcic='".$Idcic."' && alu.Idsal='".$Idsal."' && alu.Idalu='".$Idalu."' &&  alu.Idalu=cal.Idalu && cal.Idmat=mat.Idmat  ORDER BY mat.Materia, cal.Idcal ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

     $Idalu4=$row4[Idalu];

     $nom=$row4[Nombres];

     $ape=$row4[Apellidos];

     $Idcal4=$row4[Idcal];

     $tar=$row4[Tarea];

     $tra=$row4[Trabajo];

     $exa=$row4[Examen];

     $tot=$row4[Total];

     $fal=$row4[Faltas];

     $not=$row4[Nota];

      $mat=$row4[Materia];

?> 



Materia: 

<?php echo $mat; ?>

 Tareas: 

<?php echo $tar; ?>

 Trabajos: 

<?php echo $tra; ?>

 Examen: 

<?php echo $exa; ?>

 Calificación: 

<?php echo $tot; ?>



</br>



<?php

      }

}

mysqli_free_result($resultado4);

mysqli_close($db_connection);

 ?>				





					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

</div>

		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>

	



	

</html>





