<?php

include 'dat/cdb/db.php';



$Idalu = $_REQUEST['Idalu'];
$Idesc = $_REQUEST['Idesc'];
$Idcar = $_REQUEST['Idcar'];
$Idcic = $_REQUEST['Idcic'];
$Idmat = $_REQUEST['Idmat'];
$Idgra = $_REQUEST['Idgra'];
$Idsal = $_REQUEST['Idsal'];
$Iddoc = $_REQUEST['Iddoc'];



$tra = $_REQUEST['tra'];

$tar = $_REQUEST['tar'];

$exa = $_REQUEST['exa'];

$tot = $tra+$tar+$exa;

$fal = $_REQUEST['fal'];

$not = $_REQUEST['not'];


if ($Idmat>0)
{


date_default_timezone_set('America/Mexico_City');

$script_tz = date_default_timezone_get();

$date = date("Y-m-d");

$time = date('H:i:s', time());



$resultado=mysqli_query($db_connection, "SELECT Idalu FROM alumnos WHERE Idalu='".$Idalu."' ");


if (mysqli_num_rows($resultado)>0)
{

$result=mysqli_query($db_connection, "SELECT count(Idcal) par FROM calificaciones WHERE Idalu='".$Idalu."' &&  Iddoc='".$Iddoc."' &&  Idmat='".$Idmat."' ");

while ($row =mysqli_fetch_array($result))
 $par=$row[par];

$par=$par+1;


$insert_value = "INSERT INTO calificaciones (Fecha, Hora, Parcial, Trabajo, Tarea, Examen, Total, Faltas, Nota, Idmat, Iddoc, Idalu, Idcic) VALUES ('".$date."', '".$time."', '".$par."', '".$tra."', '".$tar."', '".$exa."', '".$tot."', '".$fal."', '".$not."','".$Idmat."', '".$Iddoc."', '".$Idalu."', '".$Idcic."')";



$retry_value = mysqli_query($db_connection,$insert_value);



mysqli_free_result($retry_value);


$men="Agregó la calificación";


header('Location: regcal.php?Idalu='.$Idalu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');

 } else {


$men="No se encuentra el alumno";



header('Location: regcal.php?Idalu='.$Idalu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');



}

mysqli_free_result($resultado);

mysqli_close($db_connection);
}
else{

$men="Selecciona la materia";

header('Location: regcal.php?Idalu='.$Idalu.'&Idesc='.$Idesc.'&Idcar='.$Idcar.'&Idcic='.$Idcic.'&Idmat='.$Idmat.'&Idgra='.$Idgra.'&Idsal='.$Idsal.'&Iddoc='.$Iddoc.'&men='.$men.'');

}
?>

