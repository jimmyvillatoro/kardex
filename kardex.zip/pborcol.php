<?php

include 'dat/cdb/db.php';

$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Idalu = $_REQUEST['Idalu'];
$Idcol = $_REQUEST['Idcol'];


$resultado=mysqli_query($db_connection, "SELECT Idcol FROM colegiaturas WHERE Idcol= '".$Idcol."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$delete_value = "DELETE FROM colegiaturas WHERE Idcol='".$Idcol."' && Estado=0 ";

$retry_value = mysqli_query($db_connection,$delete_value);

$men="Borró la colegiatura";


header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&Idcol='.$Idcol.'&men='.$men.'');


 } else {


$men="Seleccionar la colegiatura";

header('Location: caja.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Idalu='.$Idalu.'&Idcol='.$Idcol.'&men='.$men.'');

}

mysqli_free_result($retry_value);
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
