<?php



include 'dat/cdb/db.php';



$Idusu = $_REQUEST['Idusu'];

$Idesc = $_REQUEST['Idesc'];

$Iddoc = $_REQUEST['Iddoc'];

$Idpag = $_REQUEST['Idpag'];





$resultado=mysqli_query($db_connection, "SELECT Idpag FROM pagos WHERE Idpag= '".$Idpag."' ");

 



if (mysqli_num_rows($resultado)>0)

{



$delete_value = "DELETE FROM pagos WHERE Idpag='".$Idpag."' && Estado=0 ";



$retry_value = mysqli_query($db_connection,$delete_value);





$men="Borró el pago";



header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&Idpag='.$Idpag.'&men='.$men.'');




 } else {





$men="Seleccionar el pago";


header('Location: pagos.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Iddoc='.$Iddoc.'&Idpag='.$Idpag.'&men='.$men.'');



}



mysqli_free_result($retry_value);

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>


