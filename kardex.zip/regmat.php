<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Materias</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);

$Idcic = utf8_decode($_GET['Idcic']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idsal = utf8_decode($_GET['Idsal']);

$Idgra = utf8_decode($_GET['Idgra']);

$Iddoc = utf8_decode($_GET['Iddoc']);





$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");



while ($row =mysqli_fetch_array($resultado)) {

   	 $Nombres=$row[Nombres];

   }

mysqli_free_result($resultado);

mysqli_close($db_connection);

?>

	</head>

	

	<body>



		<div id="wrapper">

		

			<div id="logo">

				<h1>Registro de las <span>Materias</span></h1>

				

			</div>

			

			<div id="page" class="round">

			

				<div id="menu" class="round">

			<ul>



<li><a href="index.html" title="" class="round">Inicio</a></li>

<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>

				</div>

				



				

				<div id="wrapper2" class="round">

				

					<div id="sidebar" class="round">

					

			<h3>Índice</h3>

			<ul>

<li><a href="index.html" title="" class="round active">Inicio</a></li>

<li><a href="sesion.php" title="" class="round">Acceso</a></li>

<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>



			</ul>				

						



	

		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	



<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>




<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>


	<div id="splash" align="center">

<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />

				</div>



<h3>Carrera</h3>					

<ul>



<?php

include 'dat/cdb/db.php';

$Idcar = utf8_decode($_GET['Idcar']);



$resultado2=mysqli_query($db_connection, "SELECT Carrera FROM carreras WHERE  Idcar='".$Idcar."' ");



if (mysqli_num_rows($resultado2)>0)

{			  

      while ($row2 =mysqli_fetch_array($resultado2)) 

	  {



	  $Carrera=$row2[Carrera];



?> 

	<li><a><?php echo $Carrera; ?></a></li>

 

<?php

      }

}

mysqli_free_result($resultado2);

mysqli_close($db_connection);

 ?>				

</ul>

	

<h3>Registro de las Materias</h3>

						<ul>

<li> 



        <p>

            <form action="pregmat.php" method="POST">

                <p align="justify"> Los siguientes datos son necesarios.</p>



<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">



<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">



<input type="hidden" name="Idcar" value="<?php echo utf8_decode($_GET['Idcar']); ?>">





<div>

                    <div>



 <select name="gra">

Grado

  <option value="1" selected>PRIMERO</option> 

  <option value="2">SEGUNDO</option>

  <option value="3">TERCERO</option>

  <option value="4">CUARTO</option>

  <option value="5">QUINTO</option>

  <option value="6">SEXTO</option>

  <option value="7">SEPTIMO</option>

  <option value="8">OCTAVO</option>

  <option value="9">NOVENO</option>

  <option value="10">DECIMO</option>

<option value="11">ONCEAVO</option>

<option value="12">DOCEAVO</option>

  </select></td>



                    </div>

                </div>



                <div>

                    <div>



                        <input type="text" name="mat" class="form-control" placeholder="Nombre de la Materia" class="form-input" size="50"

                            required>

                    </div>


           </div>

            <div>
                    <div>

                        <input type="text" name="hor" class="form-control" placeholder="Horas Clase"

 class="form-input" size="30" required>

                    </div>

                </div>


 <div>
                    <div>

                        <input type="text" name="cos" class="form-control" placeholder="Costo por Hora"
 class="form-input" size="30" required>

                    </div>

                </div>




                <div>

                    <div>

                        <button type="submit">¡Registrar!</button>

                                   </div>

                </div>

            </form>





<h3>Actualizar Materia</h3>



<?php

include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);

$Idcar = utf8_decode($_GET['Idcar']);



$resultado3=mysqli_query($db_connection, "SELECT mat.Idmat Idmat, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idgra Idgra FROM materias mat WHERE mat.Idcar='".$Idcar."' ORDER BY mat.Idgra ");



if (mysqli_num_rows($resultado3)>0)

{			  

      while ($row3 =mysqli_fetch_array($resultado3)) 

	  {



     $Idmatz=$row3[Idmat];
     $mz=$row3[Materia];
     $hcz=$row3[HorasClase];
     $gra=$row3[Idgra];
	    $Idgraz=$gra;

if($gra==1)

$gra=

"PRIMERO";

if($gra==2)

$gra=

"SEGUNDO";

if($gra==3)

$gra=

"TERCERO";

if($gra==4)

$gra=

"CUARTO";

if($gra==5)

$gra=

"QUINTO";

if($gra==6)

$gra=

"SEXTO";

if($gra==7)

$gra=

"SEPTIMO";

if($gra==8)

$gra=

"OCTAVO";

if($gra==9)

$gra=

"NOVENO";

if($gra==10)

$gra=

"DECIMO";

if($gra==11)

$gra=

"ONCEAVO";

if($gra==12)

$gra=

"DOCEAVO";


 



?> 



<a href="regmat.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idmat=<?php echo $Idmatz; ?>&Idgra=<?php echo $Idgraz; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $gra; ?>

<?php echo $mz; ?>

<a href="pbormat.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idmat=<?php echo $Idmatz; ?>&Idgra=<?php echo $Idgraz; ?>"> <img src="dat/ima/borra.png" alt="" width="40" height="40"  class="round"/> </a>

</br>



<?php

      }

}

mysqli_free_result($resultado3);

mysqli_close($db_connection);

 ?>				

						<ul>

<li> 



 

<p>

<form action="pactmat.php" method="POST">





<?php

include 'dat/cdb/db.php';



$Idcar = utf8_decode($_GET['Idcar']);

$Idmat = utf8_decode($_GET['Idmat']);

$Idgra = utf8_decode($_GET['Idgra']);





$resultado4=mysqli_query($db_connection, "SELECT  mat.Materia Materia, mat.HorasClase HorasClase, mat.Costo Costo, gra.Grado Grado FROM grados gra, materias mat WHERE gra.Idcar='".$Idcar."' && mat.Idmat='".$Idmat."' && gra.Idgram='".$Idgra."' &&  mat.Idgra=gra.Idgram ORDER BY gra.Grado ");



if (mysqli_num_rows($resultado4)>0)

{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 

	  {

     $mx=$row4[Materia];
     $hcx=$row4[HorasClase];
	    $gx=$row4[Grado];
      $ch=$row4[Costo];

   }

}

mysqli_free_result($resultado4);
mysqli_close($db_connection);


 ?>				





<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">



<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">



<input type="hidden" name="Idcar" value="<?php echo utf8_decode($_GET['Idcar']); ?>">



<input type="hidden" name="Idmat" value="<?php echo utf8_decode($_GET['Idmat']); ?>">



<input type="hidden" name="Idgra" value="<?php echo utf8_decode($_GET['Idgra']); ?>">

 





<div>

                    <div>



 <select name="gra">

Grado

 <option value="<?php echo $gx; ?>

" selected><?php echo $gx; ?>

</option> 

 <option value="1">PRIMERO</option> 

  <option value="2">SEGUNDO</option>

  <option value="3">TERCERO</option>

  <option value="4">CUARTO</option>

  <option value="5">QUINTO</option>

  <option value="6">SEXTO</option>

  <option value="7">SEPTIMO</option>

  <option value="8">OCTAVO</option>

  <option value="9">NOVENO</option>

  <option value="10">DECIMO</option>

<option value="11">ONCEAVO</option>

<option value="12">DOCEAVO</option>

  </select>



                    </div>

                </div>



                <div>

                    <div>



                        <input type="text" name="mat" class="form-control" placeholder="Nombre de la Materia" class="form-input" size="50"

 value="<?php echo $mx; ?>

" required>

                    </div>

 </div>

           <div>

                    <div>

                        <input type="text" name="hor" class="form-control" placeholder="Horas Clase"

 class="form-input" size="30" value="<?php echo $hcx; ?>"

 required>

                    </div>

                </div>




 <div>
                    <div>

                        <input type="text" name="cos" class="form-control" placeholder="Costo por Hora"
 class="form-input" size="30"   value="<?php echo $ch; ?>"
 required>

                    </div>

                </div>




                <div>

                    <div>

                        <button type="submit">¡Actualizar!</button>

                                   </div>

                </div>

            </form>





					

<!-- termina aqui -->				

					<!-- End Content -->

					</div>

			

					<div style="clear: both"></div>

			

				<!-- End Wrapper 2 -->

				</div>

				

			<!-- End Page -->

			</div>

		

		<!-- End Wrapper -->

		</div>

		

		<div id="footer">

			

<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>

		

</div>

		

		



<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>

	



	

</html>








