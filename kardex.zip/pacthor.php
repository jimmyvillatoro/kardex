<?php

include 'dat/cdb/db.php';



$dia = $_REQUEST['dia'];
$hi = $_REQUEST['hi'];
$hf = $_REQUEST['hf'];

$h= $hi.' - '.$hf;



$Idusu = $_REQUEST['Idusu'];
$Idesc = $_REQUEST['Idesc'];
$Ideh = $_REQUEST['Ideh'];



$update_value ="UPDATE escuelash SET Dia='".$dia."', Inicioh='".$hi."', Finh='".$hf."', Horario='".$h."' WHERE Ideh='".$Ideh."' ";



$retry_value = mysqli_query($db_connection,$update_value);


$men="Horario actualizado";

header('Location: reghor.php?Idusu='.$Idusu.'&Idesc='.$Idesc.'&Ideh='.$Ideh.'&men='.$men.'');


mysqli_free_result($retry_value);

mysqli_close($db_connection);

?>

