<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Horario al Docente y Salon</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<meta name="keywords" content="" />

		<meta name="description" content="" />

		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />





<?php
include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idmat = utf8_decode($_GET['Idmat']);
$Idsal = utf8_decode($_GET['Idsal']);
$Idgra = utf8_decode($_GET['Idgra']);
$Iddoc = utf8_decode($_GET['Iddoc']);

$gra = utf8_decode($_GET['gra']);
$men = utf8_decode($_GET['men']);

$resultado=mysqli_query($db_connection, "SELECT Nombres FROM usuarios  WHERE Idusu = '".$Idusu."' ");


while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row[Nombres];
   }

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>

	</head>
	<body>

		<div id="wrapper">
			<div id="logo">

				<h1>Registro del <span>Horario</span></h1>

			</div>
			<div id="page" class="round">
				<div id="menu" class="round">

			<ul>

<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgra; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>" title="" class="round active">Atrás</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>

			</ul>
				</div>

				<div id="wrapper2" class="round">
					<div id="sidebar" class="round">

			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>



		<!-- End Sidebar -->				

					</div>			

					

					<div id="content" class="round">

					

<!-- aqui la informacion -->	

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

<p>Mensaje:<a style="color:red;"> ;] <?php echo $men; ?> </a></p>



	<div id="splash" align="center">

<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />

				</div>



<h3>Carrera</h3>					

<ul>

<?php

include 'dat/cdb/db.php';

$Idcar = utf8_decode($_GET['Idcar']);


$resultado2=mysqli_query($db_connection, "SELECT Carrera FROM carreras WHERE  Idcar='".$Idcar."' ");


if (mysqli_num_rows($resultado2)>0)
{			  

      while ($row2 =mysqli_fetch_array($resultado2))
	  {

	  $Carrera=$row2[Carrera];

?> 

<li><a><?php echo $Carrera; ?></a></li>
<?php
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>				

</ul>

<h3>Ciclo</h3>		

<ul>

<?php

include 'dat/cdb/db.php';

$Idcic = utf8_decode($_GET['Idcic']);

$result=mysqli_query($db_connection, "SELECT Ciclo, Sistema, Estado FROM ciclos WHERE Idcic = '".$Idcic."' && Estado=1 ");

while ($row1 =mysqli_fetch_array($result)) {
   	 $cic=$row1[Ciclo];
    $sis=$row1[Sistema];
    $est=$row1[Estado];

?> 

	<li><a><?php echo $cic; ?> <?php echo $sis; ?> </a></li>

<?php
   }
mysqli_free_result($result);
mysqli_close($db_connection);
?>

</ul>





<h3>Salón</h3>		

<ul>

<?php

include 'dat/cdb/db.php';

$Idsal = utf8_decode($_GET['Idsal']);

$result=mysqli_query($db_connection, "SELECT Turno, Grado, Grupo FROM salones WHERE Idsal = '".$Idsal."' ");



while ($row1 =mysqli_fetch_array($result)) {

   	 $tur=$row1[Turno];
    $gra=$row1[Grado];
    $gru=$row1[Grupo];

?> 

	<li><a><?php echo $tur; ?> <?php echo $gra; ?> <?php echo $gru; ?></a></li>

<?php
   }

mysqli_free_result($result);
mysqli_close($db_connection);
?>

</ul>



<h3>Docentes</h3>

<?php
include 'dat/cdb/db.php';

$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idsal = utf8_decode($_GET['Idsal']);


$Idmat = utf8_decode($_GET['Idmat']);
$nh = utf8_decode($_GET['nh']);


$result0=mysqli_query($db_connection, "SELECT gra.Idgra Idgra, gra.Grado Grado FROM grados gra, salones sal WHERE gra.Grado=sal.Grado && sal.Idsal='".$Idsal."' && Idcar='".$Idcar."' ");

if (mysqli_num_rows($result0)>0)
{

while ($row0 =mysqli_fetch_array($result0)) 
{
   	 $Idgrax=$row0[Idgra];
    $grax=$row0[Grado];
}

}

mysqli_free_result($result0);

$resultado4=mysqli_query($db_connection, "SELECT Iddoc, Nombres, Apellidos FROM docentes WHERE Idesc='".$Idesc."' ORDER BY Apellidos ");


if (mysqli_num_rows($resultado4)>0)
{			  

      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {

     $Iddocx=$row4[Iddoc];
     $nom=$row4[Nombres];
     $ape=$row4[Apellidos];

?> 

<a href="regrdhs.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idmat=<?php echo $Idmat; ?>&Idgra=<?php echo $Idgrax; ?>&gra=<?php echo $grax; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddocx; ?>&nh=<?php echo $nh; ?> "> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $nom; ?>
<?php echo $ape; ?>

</br>

<?php
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>	

<h3>Materia - Docente</h3>
<?php
include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idsal = utf8_decode($_GET['Idsal']);
$Iddoc = utf8_decode($_GET['Iddoc']);
$Idgra = utf8_decode($_GET['Idgra']);
$gra = utf8_decode($_GET['gra']);


$Idmat = utf8_decode($_GET['Idmat']);
$nh = utf8_decode($_GET['nh']);


$resultado7=mysqli_query($db_connection, "SELECT det.Idmd Idmd, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idmat Idmat,  doc.Nombres Nom, doc.Apellidos Ape, gra.Grado Grado, gra.Idgra Idgra FROM grados gra, materias mat, docentes doc, detallemd det WHERE  mat.Idmat=det.Idmat && doc.Iddoc=det.Iddoc &&  doc.Iddoc='".$Iddoc."' && gra.Grado='".$gra."' ORDER BY mat.Idgra ");


if (mysqli_num_rows($resultado7)>0)
{			  

while ($row7 =mysqli_fetch_array($resultado7)) 
	  {
     $Idmdj=$row7[Idmd];
     $Idmatj=$row7[Idmat];
     $mj=$row7[Materia];
     $hcj=$row7[HorasClase];
     $Idgraj=$row7[Idgra];
     $graj=$row7[Grado];
     $nj=$row7[Nom];
     $aj=$row7[Ape];


?> 
<a href="regrdhs.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>&Iddoc=<?php echo $Iddoc; ?>&Idgra=<?php echo $Idgraj; ?>&gra=<?php echo $graj; ?>&Idmat=<?php echo $Idmatj; ?>&hc=<?php echo $hcj; ?>&Idmd=<?php echo $Idmdj; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $graj; ?>
 - 
<?php echo $mj; ?>
 - 
<?php echo $hcj; ?>
 - 
<?php echo $nj; ?>
 - 
<?php echo $aj; ?>
</br>

<?php
      }
}
mysqli_free_result($resultado7);
mysqli_close($db_connection);
 ?>				


<h3>Asignación del Horario al Docente</h3>

						<ul>

<li> 

<?php

include 'dat/cdb/db.php';


$Idmat = utf8_decode($_GET['Idmat']);


$resultado5=mysqli_query($db_connection, "SELECT  Materia, HorasClase FROM materias WHERE Idmat='".$Idmat."' ");



if (mysqli_num_rows($resultado5)>0)
{			  
while ($row5 =mysqli_fetch_array($resultado5)) 
	  {

     $m5=$row5[Materia];
     $hc5=$row5[HorasClase];

?> 

Materia: 

<?php echo $m5; ?>

Horas: 

<?php echo $hc5; ?>


<?php

      }

}

mysqli_free_result($resultado5);
mysqli_close($db_connection);

 ?>





<?php

include 'dat/cdb/db.php';

$Iddoc = utf8_decode($_GET['Iddoc']);

$Idmat = utf8_decode($_GET['Idmat']);



$resultado6=mysqli_query($db_connection, "SELECT  Asignadas FROM detallemd WHERE Iddoc='".$Iddoc."' && Idmat='".$Idmat."' ");



if (mysqli_num_rows($resultado6)>0)
{			  

while ($row6 =mysqli_fetch_array($resultado6)) 
	  {

     $A6=$row6[Asignadas];

?> 

Asignadas: 
<?php echo $A6; ?>
Restantes: 
<?php echo   $r=$hc5-$A6; ?>

<?php

      }

}

mysqli_free_result($resultado6);
mysqli_close($db_connection);
 ?>	

</li> 



<li> 

        <p>

            <form action="pregrdhs.php" method="POST">


<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">

<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">

<input type="hidden" name="Idcar" value="<?php echo utf8_decode($_GET['Idcar']); ?>">

<input type="hidden" name="Idcic" value="<?php echo utf8_decode($_GET['Idcic']); ?>">

<input type="hidden" name="Idmat" value="<?php echo utf8_decode($_GET['Idmat']); ?>">

<input type="hidden" name="Idsal" value="<?php echo utf8_decode($_GET['Idsal']); ?>">

<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">

<input type="hidden" name="Idgra" value="<?php echo utf8_decode($_GET['Idgra']); ?>">

<input type="hidden" name="gra" value="<?php echo utf8_decode($_GET['gra']); ?>">

<input type="hidden" name="nh" value="<?php echo utf8_decode($_GET['nh']); ?>">


<div>
<div>

<select name="hor">

<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Iddoc = utf8_decode($_GET['Iddoc']);



$resulta=mysqli_query($db_connection, "SELECT dh.Iddh Iddh, dh.Dia Dia, dh.Horario Horario FROM docentes d, docentesh dh WHERE d.Idesc='".$Idesc."' && d.Iddoc=dh.Iddoc && dh.Estado=1 && d.Iddoc='".$Iddoc."' ORDER BY dh.Iddh ");



if (mysqli_num_rows($resulta)>0)
{			  

      while ($row911 =mysqli_fetch_array($resulta)) 
	  {

     $Iz=$row911[Iddh];
     $Hz=$row911[Horario];
     $Dz=$row911[Dia];

?> 

<option value="<?php echo $Iz; ?>
" selected>
<?php echo $Dz; ?> <?php echo $Hz; ?>
</option> 

<?php

      }
}

mysqli_free_result($resulta);
mysqli_close($db_connection);

 ?>

  </select>
</div>
</div>

                <div>

                    <div>

                        <button type="submit">¡Registrar!</button>

                                   </div>

                </div>

            </form>



	</li>

</ul> 



<h3>Actualizar el Horario al Docente</h3>

<?php

include 'dat/cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Idcar = utf8_decode($_GET['Idcar']);
$Idcic = utf8_decode($_GET['Idcic']);
$Idsal = utf8_decode($_GET['Idsal']);
$Iddoc = utf8_decode($_GET['Iddoc']);
$Idgra = utf8_decode($_GET['Idgra']);
$gra = utf8_decode($_GET['gra']);


$Idmat = utf8_decode($_GET['Idmat']);
$nh = utf8_decode($_GET['nh']);


$resultado7=mysqli_query($db_connection, "SELECT det.Idmd Idmd, mat.Materia Materia, mat.HorasClase HorasClase, mat.Idmat Idmat, gra.Grado Grado, gra.Idgra Idgra, doc.Nombres Nom, doc.Apellidos Ape,  dh.Idh Idh, dh.Horas Horas, dh.Dia, Dia, dh.Horario Horario FROM grados gra, materias mat, docentes doc, detallemd det, detalleh dh WHERE gra.Idgra='".$Idgra."' && mat.Idmat=det.Idmat && doc.Iddoc=det.Iddoc && det.Idmd=dh.Idmd && doc.Iddoc='".$Iddoc."' ORDER BY det.Idmd");


if (mysqli_num_rows($resultado7)>0)
{			  

      while ($row7 =mysqli_fetch_array($resultado7)) 

	  {

     $Idmdj=$row7[Idmd];
     $Idmatj=$row7[Idmat];
     $mz=$row7[Materia];
     $hcj=$row7[HorasClase];
     $Idgraj=$row7[Idgra];
	    $graj=$row7[Grado];
     $nj=$row7[Nom];
     $aj=$row7[Ape];
     $hj=$row7[Horas];
     $dj=$row7[Dia];
     $horj=$row7[Horario];
     $Ij=$row7[Idh];

?>

<a href="regrdhs.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>&Idgra=<?php echo $Idgraj; ?>&gra=<?php echo $graj; ?>&Idmat=<?php echo $Idmatj; ?>&Iddoc=<?php echo $Iddoc; ?>&hc=<?php echo $hcj; ?>&Idmd=<?php echo $Idmdj; ?>&Idh=<?php echo $Ij; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/></a>

<?php echo $graj; ?>
 - 
<?php echo $mz; ?>
 - 
<?php echo $hcj; ?>
 - 
<?php echo $hj; ?>
 - 
<?php echo $dj; ?>
 - 
<?php echo $horj; ?>
 - 
<?php echo $nj; ?>
 - 
<?php echo $aj; ?>


<a href="pborrdhs.php?Idusu=<?php echo $Idusu; ?>&Idesc=<?php echo $Idesc; ?>&Idcar=<?php echo $Idcar; ?>&Idcic=<?php echo $Idcic; ?>&Idsal=<?php echo $Idsal; ?>&Idgra=<?php echo $Idgraj; ?>&gra=<?php echo $graj; ?>&Idmat=<?php echo $Idmatj; ?>&Iddoc=<?php echo $Iddoc; ?>&hc=<?php echo $hcj; ?>&Idmd=<?php echo $Idmdj; ?>&Idh=<?php echo $Ij; ?>"> <img src="dat/ima/borra.png" alt="" width="40" height="40"  class="round"/></a>

</br>

<?php

      }

}

mysqli_free_result($resultado7);
mysqli_close($db_connection);

 ?>				


<form action="pactrdhs.php" method="POST">


<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">


<input type="hidden" name="Idesc" value="<?php echo utf8_decode($_GET['Idesc']); ?>">


<input type="hidden" name="Idcar" value="<?php echo utf8_decode($_GET['Idcar']); ?>">

<input type="hidden" name="Idcic" value="<?php echo utf8_decode($_GET['Idcic']); ?>">


<input type="hidden" name="Idmat" value="<?php echo utf8_decode($_GET['Idmat']); ?>">


<input type="hidden" name="Idgra" value="<?php echo utf8_decode($_GET['Idgra']); ?>">


<input type="hidden" name="Idsal" value="<?php echo utf8_decode($_GET['Idsal']); ?>">


<input type="hidden" name="Iddoc" value="<?php echo utf8_decode($_GET['Iddoc']); ?>">


<input type="hidden" name="Idmd" value="<?php echo utf8_decode($_GET['Idmd']); ?>">


<input type="hidden" name="Idh" value="<?php echo utf8_decode($_GET['Idh']); ?>">

<input type="hidden" name="gra" value="<?php echo utf8_decode($_GET['gra']); ?>">

<input type="hidden" name="nh" value="<?php echo utf8_decode($_GET['nh']); ?>">


<div>
<div>
<select name="hor">

<?php

include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idesc = utf8_decode($_GET['Idesc']);
$Iddoc = utf8_decode($_GET['Iddoc']);


$resultas=mysqli_query($db_connection, "SELECT dh.Iddh Iddh, dh.Dia Dia, dh.Horario Horario FROM docentes d, docentesh dh WHERE d.Idesc='".$Idesc."' && d.Iddoc=dh.Iddoc && dh.Estado=1 && d.Iddoc='".$Iddoc."' ORDER BY dh.Iddh ");



if (mysqli_num_rows($resultas)>0)

{			  

      while ($row91 =mysqli_fetch_array($resultas)) 

	  {

     $Iz=$row91[Iddh];
     $Hz=$row91[Horario];
     $Dz=$row91[Dia];

?> 

<option value="<?php echo $Iz; ?>
" selected>
<?php echo $Dz; ?> <?php echo $Hz; ?>
</option> 

<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);

 ?>
  </select>
</div>
</div>


                <div>

                    <div>

                        <button type="submit">¡Actualizar!</button>

                                   </div>

                </div>

            </form>

<!-- termina aqui -->				

					<!-- End Content -->

					</div>


					<div style="clear: both"></div>

				<!-- End Wrapper 2 -->

				</div>

			<!-- End Page -->

			</div>

		<!-- End Wrapper -->

		</div>

		<div id="footer">


<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>


</div>


<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>


</html>





