-- phpMyAdmin SQL Dump
-- version 4.1.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 10, 2020 at 12:26 AM
-- Server version: 5.1.62
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yaprendo_kardex`
--
CREATE DATABASE IF NOT EXISTS `yaprendo_kardex` DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;
USE `yaprendo_kardex`;

-- --------------------------------------------------------

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
CREATE TABLE IF NOT EXISTS `alumnos` (
  `Idalu` int(11) NOT NULL AUTO_INCREMENT,
  `Matricula` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Nombres` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Sexo` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Nacimiento` date NOT NULL,
  `Pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Estadocivil` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Posturareligiosa` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Estado` int(11) NOT NULL,
  `Foto` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Idesc` int(11) NOT NULL,
  `Idcar` int(11) DEFAULT NULL,
  `Idcic` int(11) DEFAULT NULL,
  `Idsal` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idalu`),
  KEY `Idcar` (`Idcar`,`Idcic`,`Idsal`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `calificaciones`
--

DROP TABLE IF EXISTS `calificaciones`;
CREATE TABLE IF NOT EXISTS `calificaciones` (
  `Idcal` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Parcial` int(11) NOT NULL,
  `Trabajo` float NOT NULL,
  `Tarea` float NOT NULL,
  `Examen` float NOT NULL,
  `Total` float NOT NULL,
  `Faltas` int(11) NOT NULL,
  `Nota` text COLLATE latin1_spanish_ci NOT NULL,
  `Idmat` int(11) DEFAULT NULL,
  `Iddoc` int(11) DEFAULT NULL,
  `Idalu` int(11) DEFAULT NULL,
  `Idcic` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idcal`),
  KEY `Idmat` (`Idmat`,`Iddoc`,`Idalu`,`Idcic`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `carreras`
--

DROP TABLE IF EXISTS `carreras`;
CREATE TABLE IF NOT EXISTS `carreras` (
  `Idcar` int(11) NOT NULL AUTO_INCREMENT,
  `Carrera` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `Revoe` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Tiempo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Dia` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Idesc` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idcar`),
  KEY `Idesc` (`Idesc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ciclos`
--

DROP TABLE IF EXISTS `ciclos`;
CREATE TABLE IF NOT EXISTS `ciclos` (
  `Idcic` int(11) NOT NULL AUTO_INCREMENT,
  `Ciclo` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Sistema` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idcar` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idcic`),
  KEY `Idcar` (`Idcar`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `colegiaturas`
--

DROP TABLE IF EXISTS `colegiaturas`;
CREATE TABLE IF NOT EXISTS `colegiaturas` (
  `Idcol` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Folio` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Descripcion` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Grado` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Mes` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Costo` float NOT NULL,
  `Descuento` float NOT NULL,
  `Recargo` float NOT NULL,
  `Importe` float NOT NULL,
  `Iva` float NOT NULL,
  `Total` float NOT NULL,
  `Letras` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idusu` int(11) DEFAULT NULL,
  `Idalu` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idcol`),
  KEY `Idusu` (`Idusu`,`Idalu`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `detalleh`
--

DROP TABLE IF EXISTS `detalleh`;
CREATE TABLE IF NOT EXISTS `detalleh` (
  `Idh` int(11) NOT NULL AUTO_INCREMENT,
  `Horas` int(11) NOT NULL,
  `Dia` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Horario` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Idmd` int(11) DEFAULT NULL,
  `Iddh` int(11) DEFAULT NULL,
  `Idsal` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idh`),
  KEY `Idcic` (`Idmd`,`Iddh`,`Idsal`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `detallemd`
--

DROP TABLE IF EXISTS `detallemd`;
CREATE TABLE IF NOT EXISTS `detallemd` (
  `Idmd` int(11) NOT NULL AUTO_INCREMENT,
  `Horas` int(11) NOT NULL,
  `Asignadas` int(11) NOT NULL,
  `Iddoc` int(11) DEFAULT NULL,
  `Idmat` int(11) DEFAULT NULL,
  `Idcic` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idmd`),
  KEY `Iddoc` (`Iddoc`,`Idmat`,`Idcic`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `docentes`
--

DROP TABLE IF EXISTS `docentes`;
CREATE TABLE IF NOT EXISTS `docentes` (
  `Iddoc` int(11) NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Sexo` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Nacimiento` date NOT NULL,
  `Pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Estadocivil` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Posturareligiosa` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Foto` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idesc` int(11) DEFAULT NULL,
  PRIMARY KEY (`Iddoc`),
  KEY `Idesc` (`Idesc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `docentesh`
--

DROP TABLE IF EXISTS `docentesh`;
CREATE TABLE IF NOT EXISTS `docentesh` (
  `Iddh` int(11) NOT NULL AUTO_INCREMENT,
  `Dia` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Horario` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Ideh` int(11) NOT NULL,
  `Iddoc` int(11) NOT NULL,
  `Idcic` int(11) NOT NULL,
  PRIMARY KEY (`Iddh`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `escuelas`
--

DROP TABLE IF EXISTS `escuelas`;
CREATE TABLE IF NOT EXISTS `escuelas` (
  `Idesc` int(11) NOT NULL AUTO_INCREMENT,
  `Escuela` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `Ubicacion` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Telefono` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Rector` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Revoe` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Firma` text COLLATE latin1_spanish_ci NOT NULL,
  `Iva` float NOT NULL,
  `Logo` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`Idesc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `escuelash`
--

DROP TABLE IF EXISTS `escuelash`;
CREATE TABLE IF NOT EXISTS `escuelash` (
  `Ideh` int(11) NOT NULL AUTO_INCREMENT,
  `Dia` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Inicioh` time NOT NULL,
  `Finh` time NOT NULL,
  `Horario` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Idesc` int(11) NOT NULL,
  PRIMARY KEY (`Ideh`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `grados`
--

DROP TABLE IF EXISTS `grados`;
CREATE TABLE IF NOT EXISTS `grados` (
  `Idgra` int(11) NOT NULL AUTO_INCREMENT,
  `Grado` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Costo` float NOT NULL,
  `Idgram` int(11) DEFAULT NULL,
  `Idcar` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idgra`),
  KEY `Idcar` (`Idcar`),
  KEY `Idgram` (`Idgram`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `materias`
--

DROP TABLE IF EXISTS `materias`;
CREATE TABLE IF NOT EXISTS `materias` (
  `Idmat` int(11) NOT NULL AUTO_INCREMENT,
  `Materia` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `HorasClase` int(11) NOT NULL,
  `Costo` float NOT NULL,
  `Idgra` int(11) DEFAULT NULL,
  `Idcar` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idmat`),
  KEY `Idgra` (`Idgra`,`Idcar`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
CREATE TABLE IF NOT EXISTS `pagos` (
  `Idpag` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Folio` int(11) NOT NULL,
  `Asignada` float NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Materia` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Costo` float NOT NULL,
  `Importe` float NOT NULL,
  `Descuento` float NOT NULL,
  `Subtotal` float NOT NULL,
  `Total` float NOT NULL,
  `Letras` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idusu` int(11) NOT NULL,
  `Idmd` int(11) NOT NULL,
  `Iddoc` int(11) DEFAULT NULL,
  `Idmat` int(11) NOT NULL,
  `Idesc` int(11) DEFAULT NULL,
  `Idcic` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idpag`),
  KEY `Idh` (`Iddoc`,`Idesc`,`Idcic`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `salones`
--

DROP TABLE IF EXISTS `salones`;
CREATE TABLE IF NOT EXISTS `salones` (
  `Idsal` int(11) NOT NULL AUTO_INCREMENT,
  `Turno` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Grado` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Grupo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Idgra` int(11) NOT NULL,
  `Idcic` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idsal`),
  KEY `Idcic` (`Idcic`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `Idusu` int(11) NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(250) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idesc` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idusu`),
  KEY `Idesc` (`Idesc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
